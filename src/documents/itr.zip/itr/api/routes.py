"""
ITR API Routes.

Production pipeline:

    Upload PDF
        ↓
    ITR Detection
        ↓
    ITR Form Extraction
        ↓
    Name + PAN + Assessment Year + DOB
        ↓
    Total Income + Business Income
        ↓
    ITR Validation
        ↓
    Authenticity Evidence Scoring
        ↓
    Minimal Explainable JSON Response

IMPORTANT:

    Validation and authenticity are deliberately separate.

    validation.valid == True

    does NOT mean:

    authenticity.verified == True

Without authoritative external verification, the system
returns UNVERIFIED rather than falsely claiming that an
ITR is genuine.
"""

from __future__ import annotations

import logging
import re
import tempfile
from pathlib import Path

import fitz

from fastapi import (
    APIRouter,
    File,
    HTTPException,
    UploadFile,
)

from ..detection.detector import ITRDetector
from ..models import DocumentType

from ..extraction.extractor import (
    extract_name,
    extract_pan,
    extract_assessment_year,
    extract_dob,
    extract_total_income,
    extract_business_income,
)

from ..validation.validation_engine import (
    ValidationEngine,
)

from ..authenticity.authenticity_scoring import (
    AuthenticityEvidenceInput,
    AuthenticityScoringEngine,
    EvidenceSeverity,
    EvidenceSignal,
)

from .schemas import (
    AuthenticityResponse,
    ITRVerifyResponse,
    ValidationResponse,
)


logger = logging.getLogger(__name__)


# ============================================================
# ROUTER
# ============================================================


router = APIRouter(
    prefix="/api/v1/itr",
    tags=["ITR"],
)


# ============================================================
# SERVICES
# ============================================================


_detector = ITRDetector()

_validator = ValidationEngine()

_authenticity_engine = (
    AuthenticityScoringEngine()
)


# ============================================================
# ITR FORM EXTRACTION
# ============================================================


def _extract_itr_form(
    text: str,
) -> str | None:
    """
    Extract ITR form number.

    Supported:

        ITR-1
        ITR-2
        ITR-3
        ITR-4
        ITR-5
        ITR-6
        ITR-7
    """

    if not text:
        return None

    normalized = re.sub(
        r"\s+",
        " ",
        text,
    ).strip()

    # --------------------------------------------------------
    # Prefer explicit Form Number.
    # --------------------------------------------------------

    explicit_pattern = re.compile(
        r"\bform\s+number\s*[:\-]?\s*"
        r"(ITR\s*[-\s]?\s*[1-7])\b",
        re.IGNORECASE,
    )

    match = explicit_pattern.search(
        normalized
    )

    if match:
        return _normalize_itr_form(
            match.group(1)
        )

    # --------------------------------------------------------
    # Fallback.
    # --------------------------------------------------------

    fallback_pattern = re.compile(
        r"\bITR\s*[-\s]?\s*([1-7])\b",
        re.IGNORECASE,
    )

    match = fallback_pattern.search(
        normalized
    )

    if match:
        return (
            f"ITR-{match.group(1)}"
        )

    return None


# ============================================================
# ITR FORM NORMALIZATION
# ============================================================


def _normalize_itr_form(
    value: str,
) -> str | None:
    """
    Normalize ITR form to ITR-N.
    """

    if not value:
        return None

    match = re.search(
        r"ITR\s*[-\s]?\s*([1-7])",
        value,
        re.IGNORECASE,
    )

    if not match:
        return None

    return (
        f"ITR-{match.group(1)}"
    )


# ============================================================
# PDF TEXT EXTRACTION
# ============================================================


def _extract_pdf_text(
    pdf_path: Path,
) -> str:
    """
    Extract native PDF text.

    OCR is intentionally not handled here yet.
    """

    document = fitz.open(
        str(pdf_path)
    )

    try:
        return "\n".join(
            page.get_text("text")
            for page in document
        )

    finally:
        document.close()


# ============================================================
# AUTHENTICITY EVIDENCE
# ============================================================


def _build_authenticity_evidence(
    validation,
) -> AuthenticityEvidenceInput:
    """
    Convert existing validation output into authenticity
    evidence.

    This is deliberately conservative.

    A successful validation does NOT create a
    "genuine" signal.

    It simply means that no validation anomaly was found.

    The final authenticity result therefore remains
    UNVERIFIED until an authoritative source is available.
    """

    signals: list[
        EvidenceSignal
    ] = []

    # --------------------------------------------------------
    # Validation decision
    # --------------------------------------------------------

    decision = str(
        getattr(
            validation,
            "decision",
            "",
        )
    ).lower()

    valid = bool(
        getattr(
            validation,
            "valid",
            False,
        )
    )

    # --------------------------------------------------------
    # INVALID DOCUMENT
    # --------------------------------------------------------

    if not valid and (
        "invalid" in decision
        or "failed" in decision
    ):
        signals.append(
            EvidenceSignal(
                rule_id=(
                    "ITR_VALIDATION_FAILURE"
                ),

                category="validation",

                severity=(
                    EvidenceSeverity.HIGH
                ),

                message=(
                    "ITR validation failed."
                ),

                reason=(
                    "The submitted ITR failed one or more "
                    "technical, content, or consistency "
                    "validation checks."
                ),

                score=85.0,

                evidence={
                    "validation_decision": decision,

                    "validation_confidence": (
                        getattr(
                            validation,
                            "confidence",
                            0.0,
                        )
                    ),
                },
            )
        )

    # --------------------------------------------------------
    # REVIEW DOCUMENT
    # --------------------------------------------------------

    elif not valid:
        signals.append(
            EvidenceSignal(
                rule_id=(
                    "ITR_VALIDATION_REVIEW"
                ),

                category="validation",

                severity=(
                    EvidenceSeverity.MEDIUM
                ),

                message=(
                    "ITR validation requires review."
                ),

                reason=(
                    "The document passed basic processing "
                    "but validation evidence was not strong "
                    "enough for automatic acceptance."
                ),

                score=45.0,

                evidence={
                    "validation_decision": decision,

                    "validation_confidence": (
                        getattr(
                            validation,
                            "confidence",
                            0.0,
                        )
                    ),
                },
            )
        )

    # --------------------------------------------------------
    # INTERNAL VALIDATION EVIDENCE
    # --------------------------------------------------------

    evidence = getattr(
        validation,
        "evidence",
        None,
    )

    if evidence is not None:

        consistency = getattr(
            evidence,
            "consistency",
            None,
        )

        if consistency is not None:

            consistent = getattr(
                consistency,
                "consistent",
                True,
            )

            if not consistent:

                reasons = getattr(
                    consistency,
                    "reasons",
                    [],
                )

                inconsistencies = getattr(
                    consistency,
                    "inconsistencies",
                    [],
                )

                signals.append(
                    EvidenceSignal(
                        rule_id=(
                            "INTERNAL_ITR_INCONSISTENCY"
                        ),

                        category="consistency",

                        severity=(
                            EvidenceSeverity.HIGH
                        ),

                        message=(
                            "Internal ITR fields are "
                            "inconsistent."
                        ),

                        reason=(
                            "Repeated or related ITR "
                            "fields contain conflicting "
                            "values."
                        ),

                        score=75.0,

                        evidence={
                            "reasons": list(
                                reasons or []
                            ),

                            "inconsistencies": list(
                                inconsistencies or []
                            ),
                        },
                    )
                )

        # ----------------------------------------------------
        # CONTENT EVIDENCE
        # ----------------------------------------------------

        content = getattr(
            evidence,
            "content",
            None,
        )

        if content is not None:

            required_content = getattr(
                content,
                "required_content_present",
                True,
            )

            if not required_content:

                missing_items = getattr(
                    content,
                    "missing_items",
                    [],
                )

                signals.append(
                    EvidenceSignal(
                        rule_id=(
                            "INCOMPLETE_ITR_CONTENT"
                        ),

                        category="content",

                        severity=(
                            EvidenceSeverity.HIGH
                        ),

                        message=(
                            "Required ITR content "
                            "is incomplete."
                        ),

                        reason=(
                            "Required fields or structural "
                            "content expected in an ITR "
                            "could not be established."
                        ),

                        score=70.0,

                        evidence={
                            "missing_items": list(
                                missing_items or []
                            ),
                        },
                    )
                )

        # ----------------------------------------------------
        # PDF INTEGRITY
        # ----------------------------------------------------

        integrity = getattr(
            evidence,
            "integrity",
            None,
        )

        if integrity is not None:

            integrity_ok = (
                bool(
                    getattr(
                        integrity,
                        "valid_file",
                        True,
                    )
                )
                and
                bool(
                    getattr(
                        integrity,
                        "valid_pdf",
                        True,
                    )
                )
                and
                not bool(
                    getattr(
                        integrity,
                        "corrupted",
                        False,
                    )
                )
            )

            if not integrity_ok:

                signals.append(
                    EvidenceSignal(
                        rule_id=(
                            "PDF_INTEGRITY_FAILURE"
                        ),

                        category="pdf_integrity",

                        severity=(
                            EvidenceSeverity.HIGH
                        ),

                        message=(
                            "PDF integrity validation failed."
                        ),

                        reason=(
                            "The submitted PDF has a "
                            "technical integrity problem "
                            "that prevents it from being "
                            "trusted as a valid document."
                        ),

                        score=90.0,

                        evidence={
                            "valid_file": (
                                getattr(
                                    integrity,
                                    "valid_file",
                                    False,
                                )
                            ),

                            "valid_pdf": (
                                getattr(
                                    integrity,
                                    "valid_pdf",
                                    False,
                                )
                            ),

                            "readable": (
                                getattr(
                                    integrity,
                                    "readable",
                                    False,
                                )
                            ),

                            "corrupted": (
                                getattr(
                                    integrity,
                                    "corrupted",
                                    False,
                                )
                            ),

                            "encrypted": (
                                getattr(
                                    integrity,
                                    "encrypted",
                                    False,
                                )
                            ),
                        },
                    )
                )

    # --------------------------------------------------------
    # SCORE
    # --------------------------------------------------------

    return AuthenticityEvidenceInput(
        signals=tuple(
            signals
        )
    )


# ============================================================
# AUTHENTICITY SERIALIZATION
# ============================================================


def _serialize_authenticity(
    result,
) -> AuthenticityResponse:
    """
    Convert scoring result into API response model.
    """

    payload = result.to_dict()

    return AuthenticityResponse(
        **payload
    )


# ============================================================
# VERIFY ITR
# ============================================================


@router.post(
    "/verify",
    response_model=ITRVerifyResponse,
)
async def verify_itr(
    file: UploadFile = File(...),
) -> ITRVerifyResponse:
    """
    Detect, extract, validate and assess authenticity
    of an ITR PDF.

    Current extraction:

        - ITR Form
        - Name
        - PAN
        - Assessment Year
        - DOB
        - Total Income
        - Business Income

    Current authenticity:

        - PDF integrity evidence
        - Content evidence
        - Internal consistency evidence
        - Validation evidence
        - Explainable risk scoring

    IMPORTANT:

        No authoritative external source is called here.

        Therefore a clean ITR is returned as:

            authenticity.verified = false

            authenticity.decision = "unverified"

        rather than falsely claiming it is genuine.
    """

    # ========================================================
    # BASIC FILE VALIDATION
    # ========================================================

    if not file.filename:

        raise HTTPException(
            status_code=400,
            detail="Filename is required",
        )

    suffix = Path(
        file.filename
    ).suffix.lower()

    if suffix != ".pdf":

        raise HTTPException(
            status_code=400,
            detail=(
                "Only PDF files are supported"
            ),
        )

    temp_path: Path | None = None

    try:

        # ====================================================
        # READ UPLOAD
        # ====================================================

        file_bytes = await file.read()

        if not file_bytes:

            raise HTTPException(
                status_code=400,
                detail=(
                    "Uploaded file is empty"
                ),
            )

        # ====================================================
        # TEMPORARY PDF
        # ====================================================

        with tempfile.NamedTemporaryFile(
            suffix=".pdf",
            delete=False,
        ) as temp_file:

            temp_file.write(
                file_bytes
            )

            temp_path = Path(
                temp_file.name
            )

        # ====================================================
        # DETECTION
        # ====================================================

        detection = _detector.detect(
            str(temp_path)
        )

        is_itr = (
            detection.detected
            and
            detection.document_type
            == DocumentType.ITR
        )

        # ====================================================
        # NON-ITR
        # ====================================================

        if not is_itr:

            return ITRVerifyResponse(
                success=True,

                document_type=(
                    detection.document_type.value
                ),

                detected=False,

                detection_confidence=(
                    detection.confidence
                ),

                itr_form=None,

                name=None,

                pan=None,

                assessment_year=None,

                dob=None,

                total_income=None,

                business_income=None,

                validation=None,

                authenticity=None,

                reason=(
                    "Document is not an ITR"
                ),
            )

        # ====================================================
        # PDF TEXT
        # ====================================================

        pdf_text = _extract_pdf_text(
            temp_path
        )

        # ====================================================
        # ITR FORM
        # ====================================================

        itr_form = _extract_itr_form(
            pdf_text
        )

        # ====================================================
        # NAME
        # ====================================================

        name = extract_name(
            pdf_text
        )

        # ====================================================
        # PAN
        # ====================================================

        pan = extract_pan(
            pdf_text
        )

        # ====================================================
        # ASSESSMENT YEAR
        # ====================================================

        assessment_year = (
            extract_assessment_year(
                pdf_text
            )
        )

        # ====================================================
        # DOB
        # ====================================================

        dob = extract_dob(
            pdf_text
        )

        # ====================================================
        # TOTAL INCOME
        # ====================================================

        total_income = (
            extract_total_income(
                pdf_text
            )
        )

        # ====================================================
        # BUSINESS INCOME
        # ====================================================

        business_income = (
            extract_business_income(
                pdf_text
            )
        )

        # ====================================================
        # VALIDATION
        # ====================================================

        validation = (
            _validator.validate_file(
                str(temp_path),

                detection_confidence=(
                    detection.confidence
                ),
            )
        )

        validation_decision = (
            validation.decision.value
        )

        # ====================================================
        # AUTHENTICITY EVIDENCE
        # ====================================================

        authenticity_input = (
            _build_authenticity_evidence(
                validation
            )
        )

        authenticity_result = (
            _authenticity_engine.analyze(
                authenticity_input
            )
        )

        authenticity_response = (
            _serialize_authenticity(
                authenticity_result
            )
        )

        # ====================================================
        # VALIDATION REASON
        # ====================================================

        if validation.valid:

            if itr_form:

                validation_reason = (
                    f"{itr_form} detected and "
                    "validation passed"
                )

            else:

                validation_reason = (
                    "ITR detected and "
                    "validation passed"
                )

        elif validation_decision == "review":

            if itr_form:

                validation_reason = (
                    f"{itr_form} requires "
                    "manual review"
                )

            else:

                validation_reason = (
                    "ITR requires "
                    "manual review"
                )

        else:

            if itr_form:

                validation_reason = (
                    f"{itr_form} detected but "
                    "validation failed"
                )

            else:

                validation_reason = (
                    "ITR detected but "
                    "validation failed"
                )

        # ====================================================
        # FINAL REASON
        # ====================================================

        reason = (
            f"{validation_reason}. "
            f"Authenticity: "
            f"{authenticity_response.reason}"
        )

        # ====================================================
        # FINAL RESPONSE
        # ====================================================

        return ITRVerifyResponse(

            success=True,

            document_type="itr",

            detected=True,

            detection_confidence=(
                detection.confidence
            ),

            itr_form=itr_form,

            name=name,

            pan=pan,

            assessment_year=assessment_year,

            dob=dob,

            total_income=total_income,

            business_income=business_income,

            validation=ValidationResponse(

                valid=validation.valid,

                decision=(
                    validation_decision
                ),

                confidence=(
                    validation.confidence
                ),
            ),

            authenticity=(
                authenticity_response
            ),

            reason=reason,
        )

    # ========================================================
    # HTTP ERROR
    # ========================================================

    except HTTPException:
        raise

    # ========================================================
    # UNEXPECTED ERROR
    # ========================================================

    except Exception as exc:

        logger.exception(
            "ITR verification API failed: %s",
            exc,
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "ITR verification failed"
            ),
        ) from exc

    # ========================================================
    # CLEANUP
    # ========================================================

    finally:

        if temp_path is not None:

            try:

                temp_path.unlink(
                    missing_ok=True
                )

            except Exception:

                logger.warning(
                    "Unable to remove temporary file: %s",
                    temp_path,
                )