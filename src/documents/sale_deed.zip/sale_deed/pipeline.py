﻿"""
Main Processing Pipeline
Fixed: No broken MergeEngine, explicit field merge, stricter regex
"""

import time
from concurrent.futures import ThreadPoolExecutor

from src.documents.sale_deed.document_loader import DocumentLoader
from src.documents.sale_deed.quality_checker import QualityChecker
from src.documents.sale_deed.image_enhancer import ImageEnhancer
from src.documents.sale_deed.ocr_engine import OCREngine

from src.documents.sale_deed.agents.verification_agent import VerificationAgent
from src.documents.sale_deed.agents.extraction_agent import ExtractionAgent
from src.documents.sale_deed.agents.validation_agent import ValidationAgent


class SaleDeedPipeline:

    def __init__(self):
        self.ocr = OCREngine()
        self.verification_agent = VerificationAgent()
        self.extraction_agent = ExtractionAgent()
        self.validation_agent = ValidationAgent()

    # =====================================================
    # Process One Page
    # =====================================================

    def prepare_page(self, image, page_number):
        checker = QualityChecker(image)
        quality = checker.run_all_checks()
        score = quality["quality_score"]
        print(f"Page {page_number} | Quality : {score}%")

        enhancer = ImageEnhancer(image)
        if score >= 95:
            enhanced_image = image
            print(f"Page {page_number} : Enhancement Skipped")
        else:
            enhanced_image = enhancer.process(
                denoise=True, contrast=True, sharpen=True, binarize=False
            )
            print(f"Page {page_number} : Enhanced")

        output_path = enhancer.save_image(enhanced_image, f"page_{page_number}.png")
        return output_path

    # =====================================================
    # Parallel Page Preparation
    # =====================================================

    def prepare_pages_parallel(self, pages):
        print("\nPreparing Pages...\n")
        start = time.time()
        workers = 1

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [
                executor.submit(self.prepare_page, page, idx)
                for idx, page in enumerate(pages, start=1)
            ]
            enhanced_pages = [future.result() for future in futures]

        print(f"\n{'='*60}")
        print("Page Preparation Completed")
        print(f"Workers : {workers}")
        print(f"Pages   : {len(enhanced_pages)}")
        print(f"Time    : {time.time()-start:.2f} sec")
        print("=" * 60)
        return enhanced_pages

    # =====================================================
    # Complete Pipeline
    # =====================================================

    def verify_document(self, file_path):
        total_start = time.time()
        loader = DocumentLoader(file_path)
        page_count = 1

        # ------------------------------------------------
        # Load Document
        # ------------------------------------------------

        if loader.has_embedded_text():
            print("Embedded PDF Detected")
            document_text = loader.extract_text()
        else:
            print("Scanned Document Detected")
            t1 = time.time()
            pages = loader.extract_images()
            print(f"PDF converted in {time.time()-t1:.2f} sec")
            page_count = len(pages)
            enhanced_pages = self.prepare_pages_parallel(pages)
            t2 = time.time()
            document_text = self.ocr.extract_text(enhanced_pages)
            print(f"OCR Time : {time.time()-t2:.2f} sec")

        # ------------------------------------------------
        # Empty Check
        # ------------------------------------------------

        if not document_text.strip():
            return {
                "status": "failed",
                "message": "No text extracted.",
                "verification": None,
                "classification": None,
                "extraction": None
            }

        # =====================================================
        # Verification Agent
        # =====================================================

        t3 = time.time()
        verification = self.verification_agent.analyze(document_text)
        print(f"Verification Agent : {time.time()-t3:.2f} sec")

        classification = {
            "document_type": verification.get("document_type", "Unknown"),
            "confidence": verification.get("confidence", 0)
        }

        # =====================================================
        # Stop if not a Sale Deed
        # =====================================================

        if not verification.get("verified", False):
            print(f"\n{'='*70}")
            print(f"TOTAL PIPELINE TIME : {time.time()-total_start:.2f} sec")
            print("=" * 70)
            return {
                "status": "failed",
                "document_type": verification.get("document_type", "Unknown"),
                "page_count": page_count,
                "verification": verification,
                "classification": classification,
                "extraction": {}
            }

        # =====================================================
        # Extraction (New Modular Engine)
        # =====================================================

        t4 = time.time()
        extraction = self.extraction_agent.extract(document_text)
        print(f"Extraction Agent : {time.time()-t4:.2f} sec")

        if isinstance(extraction, dict) and "data" in extraction:
            final_data = extraction["data"]
        else:
            final_data = extraction

        merged_extraction = {"success": True, "data": final_data}

        # =====================================================
        # Validation Agent
        # =====================================================

        validation = self.validation_agent.validate(final_data)

        # =====================================================

        print(f"\n{'='*70}")
        print(f"TOTAL PIPELINE TIME : {time.time()-total_start:.2f} sec")
        print("=" * 70)

        return {
            "status": "success",
            "document_type": "Sale Deed",
            "page_count": page_count,
            "verification": verification,
            "classification": classification,
            "validation": validation,
            "extraction": merged_extraction
        }
