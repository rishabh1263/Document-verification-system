﻿"""
Sale Deed Verification API Routes.

Provides the Sale Deed verification endpoint for the unified
document-verification-system.

The Sale Deed + Aadhaar identity-comparison endpoint is intentionally
not initialized here because the original standalone project is missing
the source file:

    src/aadhaar/extraction_engine.py

Only a stale compiled .pyc exists in the old project.
"""

from pathlib import Path
import shutil
import uuid

from fastapi import APIRouter, File, HTTPException, UploadFile

from src.documents.sale_deed.pipeline import SaleDeedPipeline


# ==========================================================
# Router
# ==========================================================

router = APIRouter(
    tags=["Sale Deed"]
)


# ==========================================================
# Configuration
# ==========================================================

ALLOWED_EXTENSIONS = {
    ".pdf",
    ".png",
    ".jpg",
    ".jpeg",
    ".tif",
    ".tiff",
}

MAX_FILE_SIZE = 25 * 1024 * 1024  # 25 MB


# ==========================================================
# Upload Directory
# ==========================================================

SALE_DEED_ROOT = Path(__file__).resolve().parents[1]

UPLOAD_DIR = SALE_DEED_ROOT / "uploads"

UPLOAD_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


# ==========================================================
# Initialize Pipeline
# ==========================================================

pipeline = SaleDeedPipeline()


# ==========================================================
# Helpers
# ==========================================================

def _validate_filename(
    filename: str | None,
) -> tuple[str, str]:

    if not filename:
        raise HTTPException(
            status_code=400,
            detail="Uploaded file must have a filename.",
        )

    extension = Path(filename).suffix.lower()

    if extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unsupported file type '{extension}'. "
                f"Allowed types: "
                f"{', '.join(sorted(ALLOWED_EXTENSIONS))}"
            ),
        )

    return filename, extension


async def _save_upload(
    file: UploadFile,
) -> Path:

    filename, extension = _validate_filename(
        file.filename
    )

    content = await file.read()

    if not content:
        raise HTTPException(
            status_code=400,
            detail="Uploaded file is empty.",
        )

    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=413,
            detail="Uploaded file exceeds the 25 MB limit.",
        )

    # Do not directly trust the uploaded filename for disk storage.
    # A generated filename also prevents collisions between requests.
    safe_filename = (
        f"{uuid.uuid4().hex}{extension}"
    )

    file_path = UPLOAD_DIR / safe_filename

    try:
        with open(file_path, "wb") as buffer:
            buffer.write(content)

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail="Unable to store uploaded Sale Deed.",
        ) from exc

    return file_path


# ==========================================================
# Health
# ==========================================================

@router.get("/health")
async def sale_deed_health():

    return {
        "document": "sale_deed",
        "status": "healthy",
    }


# ==========================================================
# Verify Sale Deed
# ==========================================================

@router.post("/verify")
async def verify_sale_deed(
    file: UploadFile = File(...),
):

    file_path: Path | None = None

    try:

        file_path = await _save_upload(file)

        result = pipeline.verify_document(
            str(file_path)
        )

        return result

    except HTTPException:
        raise

    except ValueError as exc:

        raise HTTPException(
            status_code=422,
            detail=str(exc),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Sale Deed verification failed: "
                f"{str(exc)}"
            ),
        ) from exc

    finally:

        if (
            file_path is not None
            and file_path.exists()
        ):
            file_path.unlink(
                missing_ok=True
            )

        await file.close()