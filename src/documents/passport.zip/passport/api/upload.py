﻿from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile

from src.documents.passport.storage.file_manager import FileManager
from src.documents.passport.storage.metadata_manager import MetadataManager
from src.documents.passport.utils.request_id import generate_request_id
from src.documents.passport.preprocessing.pipeline.preprocessing_pipeline import PreprocessingPipeline
from src.documents.passport.verification.pipeline.verification_pipeline import VerificationPipeline

router = APIRouter()

SUPPORTED_FORMATS = {
    ".pdf",
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".tiff",
}


@router.post("/upload")
async def upload(file: UploadFile = File(...)):
    """
    Upload, preprocess, and verify a passport.
    """

    extension = Path(file.filename).suffix.lower()

    if extension not in SUPPORTED_FORMATS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format: {extension}"
        )

    request_id = generate_request_id()

    saved_file = FileManager.save(file)

    try:
        preprocessing_result = PreprocessingPipeline.process(
            saved_file["path"]
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Preprocessing failed: {str(e)}"
        )

    try:
        verification_result = VerificationPipeline.verify(
            preprocessing_result
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Verification failed: {str(e)}"
        )

    MetadataManager.save(
        request_id=request_id,
        data={
            "request_id": request_id,
            "original_filename": file.filename,
            "stored_filename": saved_file["filename"],
            "file_path": saved_file["path"],
            "file_type": extension,
            "verification_result": verification_result,
            "status": "VERIFIED"
        }
    )

    return {
        "request_id": request_id,
        "verification": {
            "document_type": verification_result["document_type"],
            "status": verification_result["status"],
            "decision": verification_result["decision"],
            "confidence": verification_result["confidence"],
            "authenticity_score": verification_result["authenticity_score"],
            "forgery_score": verification_result["forgery_score"],
            "issues": verification_result["issues"]
        }
    }
