﻿"""
Passport module configuration.

Configuration is kept inside the Passport module so that the module
can be plugged into the unified Document Verification System without
depending on the old standalone Passport project.
"""

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


# ============================================================
# Passport module paths
# ============================================================

PASSPORT_ROOT = Path(__file__).resolve().parents[1]

PASSPORT_STORAGE_DIR = PASSPORT_ROOT / "storage_data"


# ============================================================
# Settings
# ============================================================

class Settings(BaseSettings):
    """
    Configuration used by the Passport verification module.
    """

    APP_NAME: str = "Passport Verification"

    APP_VERSION: str = "1.0.0"

    DEBUG: bool = True

    HOST: str = "127.0.0.1"

    PORT: int = 8000

    STORAGE_DIR: str = str(
        PASSPORT_STORAGE_DIR
    )

    UPLOAD_DIR: str = str(
        PASSPORT_STORAGE_DIR / "uploads"
    )

    LOG_DIR: str = str(
        PASSPORT_STORAGE_DIR / "logs"
    )

    REPORT_DIR: str = str(
        PASSPORT_STORAGE_DIR / "reports"
    )

    METADATA_DIR: str = str(
        PASSPORT_STORAGE_DIR / "metadata"
    )

    model_config = SettingsConfigDict(
        extra="ignore",
    )


# ============================================================
# Settings instance
# ============================================================

settings = Settings()
