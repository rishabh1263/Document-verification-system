﻿SUPPORTED_IMAGE_FORMATS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".tiff"
}

SUPPORTED_DOCUMENT_FORMATS = {
    ".pdf"
}

MAX_FILE_SIZE_MB = 25

API_PREFIX = "/api/v1"
