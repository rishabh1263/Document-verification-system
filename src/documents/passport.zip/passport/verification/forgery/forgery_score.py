﻿class ForgeryScore:
    """
    Calculates forgery risk.

    Score:
        0   -> No forgery evidence
        100 -> Strong forgery evidence
    """

    WEIGHTS = {

        "blur": 15,

        "noise": 20,

        "jpeg": 20,

        "edge": 15,

        "illumination": 10,

        "copy_move": 20

    }

    @classmethod
    def calculate(
        cls,
        blur,
        noise,
        jpeg,
        edge,
        illumination,
        copy_move
    ):

        detectors = {

            "blur": blur,

            "noise": noise,

            "jpeg": jpeg,

            "edge": edge,

            "illumination": illumination,

            "copy_move": copy_move

        }

        forgery_score = 0

        details = {}

        warnings = []

        for name, result in detectors.items():

            weight = cls.WEIGHTS[name]

            if result.get("passed", False):

                details[name] = 0

            else:

                forgery_score += weight

                details[name] = weight

                warnings.append(
                    result.get(
                        "reason",
                        f"{name} anomaly detected."
                    )
                )

        confidence = round(
            forgery_score / 100,
            2
        )

        if forgery_score <= 20:

            decision = "NO_FORGERY_DETECTED"

        elif forgery_score <= 40:

            decision = "LOW_RISK"

        elif forgery_score <= 70:

            decision = "MEDIUM_RISK"

        else:

            decision = "HIGH_RISK"

        return {

            "score": forgery_score,

            "confidence": confidence,

            "decision": decision,

            "details": details,

            "warnings": warnings

        }
