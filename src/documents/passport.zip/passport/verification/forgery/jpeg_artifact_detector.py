﻿import cv2
import numpy as np


class JPEGArtifactDetector:
    """
    Detect JPEG compression inconsistencies using
    block boundary analysis.
    """

    BLOCK_SIZE = 8

    def analyze(self, image_path):

        image = cv2.imread(image_path)

        if image is None:

            return {

                "passed": False,

                "reason": "Unable to load image."

            }

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        h, w = gray.shape

        vertical_scores = []

        horizontal_scores = []

        # Vertical JPEG boundaries

        for x in range(self.BLOCK_SIZE, w, self.BLOCK_SIZE):

            diff = np.abs(

                gray[:, x].astype(np.float32)

                -

                gray[:, x - 1].astype(np.float32)

            )

            vertical_scores.append(np.mean(diff))

        # Horizontal JPEG boundaries

        for y in range(self.BLOCK_SIZE, h, self.BLOCK_SIZE):

            diff = np.abs(

                gray[y, :].astype(np.float32)

                -

                gray[y - 1, :].astype(np.float32)

            )

            horizontal_scores.append(np.mean(diff))

        vertical_mean = float(np.mean(vertical_scores))
        horizontal_mean = float(np.mean(horizontal_scores))

        artifact_score = (

            vertical_mean +

            horizontal_mean

        ) / 2

        # Empirical threshold

        passed = artifact_score < 15

        return {

            "passed": passed,

            "artifact_score": round(
                artifact_score,
                2
            ),

            "vertical_mean": round(
                vertical_mean,
                2
            ),

            "horizontal_mean": round(
                horizontal_mean,
                2
            ),

            "reason": (
                "JPEG compression appears consistent."
                if passed
                else
                "Possible JPEG recompression artifacts detected."
            )

        }
