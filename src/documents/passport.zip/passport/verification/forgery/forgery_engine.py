﻿from src.documents.passport.verification.forgery.blur_analysis import BlurAnalysis
from src.documents.passport.verification.forgery.noise_analysis import NoiseAnalysis
from src.documents.passport.verification.forgery.jpeg_artifact_detector import JPEGArtifactDetector
from src.documents.passport.verification.forgery.edge_consistency import EdgeConsistency
from src.documents.passport.verification.forgery.illumination_analysis import IlluminationAnalysis
from src.documents.passport.verification.forgery.copy_move_detector import CopyMoveDetector
from src.documents.passport.verification.forgery.forgery_score import ForgeryScore


class ForgeryEngine:
    """
    Runs all forgery detectors.
    """

    def __init__(self):

        self.blur = BlurAnalysis()

        self.noise = NoiseAnalysis()

        self.jpeg = JPEGArtifactDetector()

        self.edge = EdgeConsistency()

        self.illumination = IlluminationAnalysis()

        self.copy_move = CopyMoveDetector()

    def analyze(self, image_path):

        results = {

            "blur": self.blur.analyze(image_path),

            "noise": self.noise.analyze(image_path),

            "jpeg": self.jpeg.analyze(image_path),

            "edge": self.edge.analyze(image_path),

            "illumination": self.illumination.analyze(image_path),

            "copy_move": self.copy_move.analyze(image_path)

        }

        summary = ForgeryScore.calculate(

            blur=results["blur"],

            noise=results["noise"],

            jpeg=results["jpeg"],

            edge=results["edge"],

            illumination=results["illumination"],

            copy_move=results["copy_move"]

        )

        return {

            "passed": summary["score"] <= 40,

            "analysis": results,

            "summary": summary

        }
