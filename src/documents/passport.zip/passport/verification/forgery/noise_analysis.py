﻿import cv2
import numpy as np


class NoiseAnalysis:
    """
    Analyze local noise consistency across the image.
    Large differences in noise may indicate edited regions.
    """

    def __init__(self, block_size=128):
        self.block_size = block_size

    @staticmethod
    def estimate_noise(gray):

        blur = cv2.GaussianBlur(gray, (3, 3), 0)

        noise = cv2.absdiff(gray, blur)

        return float(np.std(noise))

    def analyze(self, image_path):

        image = cv2.imread(image_path)

        if image is None:
            return {
                "passed": False,
                "reason": "Unable to load image."
            }

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        h, w = gray.shape

        blocks = []

        for y in range(0, h, self.block_size):
            for x in range(0, w, self.block_size):

                block = gray[
                    y:min(y + self.block_size, h),
                    x:min(x + self.block_size, w)
                ]

                if block.size == 0:
                    continue

                value = self.estimate_noise(block)

                blocks.append({

                    "x": x,
                    "y": y,
                    "width": block.shape[1],
                    "height": block.shape[0],
                    "noise": round(value, 2)

                })

        values = np.array(
            [b["noise"] for b in blocks],
            dtype=np.float32
        )

        mean = float(np.mean(values))
        std = float(np.std(values))

        suspicious = []

        lower = mean - 2 * std
        upper = mean + 2 * std

        for block in blocks:

            if block["noise"] < lower or block["noise"] > upper:

                suspicious.append(block)

        ratio = len(suspicious) / max(len(blocks), 1)

        return {

            "passed": ratio < 0.20,

            "mean_noise": round(mean, 2),

            "std_noise": round(std, 2),

            "total_blocks": len(blocks),

            "suspicious_blocks": len(suspicious),

            "suspicious_ratio": round(ratio, 3),

            "regions": suspicious,

            "reason": (
                "Noise distribution appears consistent."
                if ratio < 0.20
                else
                "Noise inconsistencies detected."
            )

        }
