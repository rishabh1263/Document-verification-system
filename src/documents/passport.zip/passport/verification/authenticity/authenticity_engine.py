﻿from src.documents.passport.verification.authenticity.photo_detector import PhotoDetector
from src.documents.passport.verification.authenticity.signature_detector import SignatureDetector
from src.documents.passport.verification.authenticity.emblem_detector import EmblemDetector
from src.documents.passport.verification.authenticity.layout_consistency import LayoutConsistency
from src.documents.passport.verification.authenticity.security_feature_detector import (
    SecurityFeatureDetector,
)
from src.documents.passport.verification.authenticity.authenticity_score import (
    AuthenticityScore,
)


class AuthenticityEngine:
    """
    Coordinates all passport authenticity verification modules.
    """

    def __init__(self):

        self.photo_detector = PhotoDetector()

        self.signature_detector = SignatureDetector()

        self.emblem_detector = EmblemDetector()

        self.layout_detector = LayoutConsistency()

        self.security_detector = SecurityFeatureDetector()

    def verify(
        self,
        image_path,
        mrz_validation,
        field_consistency,
        quality_result
    ):
        """
        Run all authenticity checks.

        Args:
            image_path (str): Passport image path.
            mrz_validation (dict): MRZ validation result.
            field_consistency (dict): OCR â†” MRZ consistency result.
            quality_result (dict): Image quality assessment.

        Returns:
            dict
        """

        photo = self.photo_detector.detect(
            image_path
        )

        signature = self.signature_detector.detect(
            image_path
        )

        emblem = self.emblem_detector.detect(
            image_path
        )

        layout = self.layout_detector.detect(
            image_path=image_path,
            photo_result=photo,
            signature_result=signature,
            emblem_result=emblem,
            mrz_result=mrz_validation

        )

        security = self.security_detector.detect(
            image_path=image_path,
            mrz_result=mrz_validation
        )

        security_features = {

            "photo": photo,

            "signature": signature,

            "emblem": emblem,

            "layout": layout,

            "security": security

        }

        final_score = AuthenticityScore.calculate(

            mrz_validation=mrz_validation,

            field_consistency=field_consistency,

            security_features=security_features,

            quality_result=quality_result

        )

        return {

            "passed": final_score["decision"] in (
                "GENUINE",
                "LIKELY_GENUINE"
            ),

            "security_features": security_features,

            "authenticity": final_score

        }
