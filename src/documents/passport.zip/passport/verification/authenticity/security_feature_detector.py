﻿import cv2

from src.documents.passport.verification.authenticity.photo_detector import PhotoDetector
from src.documents.passport.verification.authenticity.signature_detector import SignatureDetector
from src.documents.passport.verification.authenticity.emblem_detector import EmblemDetector
from src.documents.passport.verification.authenticity.layout_consistency import LayoutConsistency


class SecurityFeatureDetector:
    """
    Runs all visual security feature detectors and
    combines their results.
    """

    def __init__(self):

        self.photo_detector = PhotoDetector()
        self.signature_detector = SignatureDetector()
        self.emblem_detector = EmblemDetector()

    def detect(
        self,
        image_path,
        mrz_result
    ):

        image = cv2.imread(image_path)

        if image is None:

            return {
                "passed": False,
                "reason": "Unable to load image."
            }

        height, width = image.shape[:2]

        # ----------------------------
        # Individual detectors
        # ----------------------------

        photo_result = self.photo_detector.detect(
            image_path
        )

        signature_result = self.signature_detector.detect(
            image_path
        )

        emblem_result = self.emblem_detector.detect(
            image_path
        )

        # ----------------------------
        # Layout validation
        # ----------------------------

        layout_result = LayoutConsistency.validate(
            image_width=width,
            image_height=height,
            photo_result=photo_result,
            signature_result=signature_result,
            emblem_result=emblem_result,
            mrz_result=mrz_result
        )

        # ----------------------------
        # Summary
        # ----------------------------

        feature_results = {

            "photo": photo_result,

            "signature": signature_result,

            "emblem": emblem_result,

            "layout": layout_result

        }

        passed_count = sum(
            1
            for feature in feature_results.values()
            if feature.get("passed", False)
        )

        total_features = len(feature_results)

        score = round(
            (passed_count / total_features) * 100,
            2
        )

        return {

            "passed": passed_count == total_features,

            "score": score,

            "passed_features": passed_count,

            "total_features": total_features,

            "features": feature_results

        }
