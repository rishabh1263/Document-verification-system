﻿class AuthenticityScore:
    """
    Calculates the overall passport authenticity score.
    """

    WEIGHTS = {

        "mrz_validation": 30,

        "field_consistency": 25,

        "photo": 10,

        "layout": 10,

        "emblem": 8,

        "signature": 7,

        "quality": 10

    }

    @classmethod
    def calculate(
        cls,
        mrz_validation,
        field_consistency,
        security_features,
        quality_result
    ):

        score = 0.0

        details = {}

        reasons = []

        # ----------------------------
        # MRZ Validation
        # ----------------------------

        mrz_weight = cls.WEIGHTS["mrz_validation"]

        mrz_conf = mrz_validation.get(
            "confidence",
            1.0 if mrz_validation.get("valid", False) else 0.0
        )

        mrz_score = mrz_weight * mrz_conf

        score += mrz_score

        details["mrz_validation"] = round(mrz_score, 2)

        reasons.append(
            "MRZ validation passed."
            if mrz_validation.get("valid", False)
            else "MRZ validation failed."
        )

        # ----------------------------
        # OCR â†” MRZ Consistency
        # ----------------------------

        field_weight = cls.WEIGHTS["field_consistency"]

        field_conf = field_consistency.get(
            "confidence",
            field_consistency.get("score", 0) / 100
        )

        field_score = field_weight * field_conf

        score += field_score

        details["field_consistency"] = round(field_score, 2)

        reasons.append(
            "OCR fields match MRZ."
            if field_consistency.get("passed", False)
            else "OCR fields partially match MRZ."
        )

        # ----------------------------
        # Individual Security Features
        # ----------------------------

        for feature in [

            "photo",

            "layout",

            "emblem",

            "signature"

        ]:

            weight = cls.WEIGHTS[feature]

            result = security_features.get(
                feature,
                {}
            )

            conf = result.get(
                "confidence",
                1.0 if result.get("passed", False) else 0.0
            )

            feature_score = weight * conf

            score += feature_score

            details[feature] = round(
                feature_score,
                2
            )

            reasons.append(

                f"{feature.title()} detected."

                if result.get("passed", False)

                else

                f"{feature.title()} not detected."

            )

        # ----------------------------
        # Image Quality
        # ----------------------------

        quality_weight = cls.WEIGHTS["quality"]

        quality_conf = quality_result.get(
            "confidence",
            1.0 if quality_result.get("passed", False) else 0.0
        )

        quality_score = quality_weight * quality_conf

        score += quality_score

        details["quality"] = round(
            quality_score,
            2
        )

        reasons.append(

            "Image quality acceptable."

            if quality_result.get("passed", False)

            else

            "Poor image quality."

        )

        score = round(score, 2)

        confidence = round(score / 100, 2)

        # ----------------------------
        # Decision
        # ----------------------------

        if score >= 90:

            decision = "GENUINE"

        elif score >= 75:

            decision = "LIKELY_GENUINE"

        elif score >= 55:

            decision = "SUSPICIOUS"

        else:

            decision = "LIKELY_FAKE"

        return {

            "score": score,

            "confidence": confidence,

            "decision": decision,

            "details": details,

            "reasons": reasons

        }
