﻿import os

import cv2


class EmblemDetector:
    """
    Detect the Indian passport emblem using ORB feature matching.
    """

    def __init__(self):

        # Current file:
        # src/documents/passport/verification/authenticity/emblem_detector.py
        #
        # Passport root:
        # src/documents/passport/
        passport_root = os.path.abspath(
            os.path.join(
                os.path.dirname(__file__),
                "..",
                "..",
            )
        )

        template_path = os.path.join(
            passport_root,
            "assets",
            "templates",
            "india_emblem.jpeg",
        )

        self.template = cv2.imread(
            template_path,
            cv2.IMREAD_GRAYSCALE,
        )

        if self.template is None:
            raise FileNotFoundError(
                f"Template not found: {template_path}"
            )

        self.orb = cv2.ORB_create(
            nfeatures=500
        )

        self.matcher = cv2.BFMatcher(
            cv2.NORM_HAMMING,
            crossCheck=True,
        )

        self.kp_template, self.des_template = (
            self.orb.detectAndCompute(
                self.template,
                None,
            )
        )

    def detect(self, image_path):

        image = cv2.imread(
            image_path,
            cv2.IMREAD_GRAYSCALE,
        )

        if image is None:
            return {
                "detected": False,
                "passed": False,
                "matches": 0,
                "reason": "Unable to load image.",
            }

        height, width = image.shape

        # Top-center region of passport
        roi = image[
            0:int(height * 0.35),
            int(width * 0.20):int(width * 0.80),
        ]

        kp_roi, des_roi = self.orb.detectAndCompute(
            roi,
            None,
        )

        if des_roi is None or self.des_template is None:
            return {
                "detected": False,
                "passed": False,
                "good_matches": 0,
                "total_matches": 0,
                "reason": "No ORB descriptors found.",
            }

        matches = self.matcher.match(
            self.des_template,
            des_roi,
        )

        matches = sorted(
            matches,
            key=lambda x: x.distance,
        )

        good_matches = [
            m
            for m in matches
            if m.distance < 50
        ]

        detected = len(good_matches) >= 20

        return {
            "detected": detected,
            "passed": detected,
            "good_matches": len(good_matches),
            "total_matches": len(matches),
            "reason": (
                "Indian emblem detected."
                if detected
                else "Indian emblem not detected."
            ),
        }