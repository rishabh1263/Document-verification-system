﻿import cv2
import numpy as np


class PhotoDetector:
    """
    Passport photo detector.

    Uses:
    - texture
    - edge density
    - variance

    instead of Haar cascades.
    """

    def detect(self, image_path):

        image = cv2.imread(image_path)

        if image is None:
            return {
                "detected": False,
                "passed": False,
                "confidence": 0.0,
                "reason": "Unable to load image."
            }

        h, w = image.shape[:2]

        # Expected portrait region
        x1 = int(w * 0.40)
        x2 = int(w * 0.90)

        y1 = int(h * 0.08)
        y2 = int(h * 0.78)

        roi = image[y1:y2, x1:x2]

        if roi.size == 0:

            return {
                "detected": False,
                "passed": False,
                "confidence": 0.0,
                "reason": "Invalid photo region."
            }

        gray = cv2.cvtColor(
            roi,
            cv2.COLOR_BGR2GRAY
        )

        edges = cv2.Canny(
            gray,
            50,
            150
        )

        edge_density = np.count_nonzero(edges) / edges.size

        variance = cv2.Laplacian(
            gray,
            cv2.CV_64F
        ).var()

        texture = np.std(gray)

        score = 0

        if edge_density > 0.015:
            score += 1

        if variance > 80:
            score += 1

        if texture > 18:
            score += 1

        confidence = round(score / 3, 2)

        detected = confidence >= 0.50

        return {

            "detected": detected,

            "passed": detected,

            "confidence": confidence,

            "edge_density": round(
                edge_density,
                4
            ),

            "variance": round(
                variance,
                2
            ),

            "texture": round(
                texture,
                2
            ),

            "bounding_box": {

                "x": x1,

                "y": y1,

                "width": x2 - x1,

                "height": y2 - y1

            }

        }
