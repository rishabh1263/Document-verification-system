﻿from src.documents.passport.verification.layout.layout_verifier import LayoutVerifier
from src.documents.passport.verification.mrz.mrz_detector import MRZDetector
from src.documents.passport.verification.mrz.mrz_parser import MRZParser
from src.documents.passport.verification.mrz.mrz_validator import MRZValidator
from src.documents.passport.verification.ocr.ocr_engine import OCREngine
from src.documents.passport.verification.classifier.document_classifier import DocumentClassifier
from src.documents.passport.verification.analysis.page_analyzer import PageAnalyzer
from src.documents.passport.verification.fields.field_extractor import FieldExtractor
from src.documents.passport.verification.fields.field_validator import FieldValidator
from src.documents.passport.verification.authenticity.authenticity_engine import AuthenticityEngine
from src.documents.passport.verification.forgery.forgery_engine import ForgeryEngine
from src.documents.passport.verification.decision.decision_engine import DecisionEngine
from src.documents.passport.verification.decision.verification_report import VerificationReport


class VerificationPipeline:

    @classmethod
    def verify(cls, preprocessing_result):

        processed_images = preprocessing_result["processed_images"]
        quality_results = preprocessing_result["quality"]

        pages = []

        best_page = None

        highest_score = -1

        passport_pages = 0

        non_passport_pages = 0

        for index, image in enumerate(processed_images, start=1):

            print("\n=================================================")
            print(f"Processing Page {index}")
            print("=================================================\n")

            layout = LayoutVerifier.verify(image)

            mrz_detector = MRZDetector.detect(image)

            ocr = OCREngine.extract_text(image)

            print("\n--------------- OCR TEXT ----------------")
            print(ocr["text"])
            print("-----------------------------------------\n")

            mrz_parsed = MRZParser.parse(
                ocr["text"]
            )

            print("\n============= PARSED MRZ =============")
            print(mrz_parsed)
            print("======================================\n")

            mrz_validation = MRZValidator.validate(
                mrz_parsed
            )

            print("\n=========== MRZ VALIDATION ===========")
            print(mrz_validation)
            print("======================================\n")

            visible_fields = FieldExtractor.extract(
                ocr
            )

            field_validation = FieldValidator.validate(
                visible_fields,
                mrz_parsed
            )

            print("\n========== FIELD CONSISTENCY ==========")
            print(field_validation)
            print("=======================================\n")

            document = DocumentClassifier.classify(
                ocr["text"]
            )

            analysis = PageAnalyzer.analyze(
                page_number=index,
                layout=layout,
                mrz=mrz_detector,
                document=document
            )

            if document["document_type"] == "PASSPORT":
                passport_pages += 1
            else:
                non_passport_pages += 1

            page = {

                "image": image,

                "quality": quality_results[index - 1],

                "layout": layout,

                "ocr": ocr,

                "mrz": {

                    "detector": mrz_detector,

                    "parsed": mrz_parsed,

                    "validation": mrz_validation

                },

                "fields": {

                    "visible": visible_fields,

                    "consistency": field_validation

                },

                "document": document,

                "analysis": analysis

            }

            pages.append(page)

            if analysis["score"] > highest_score:

                highest_score = analysis["score"]

                best_page = index

        for page in pages:

            page["analysis"]["candidate"] = (

                page["analysis"]["page"] == best_page

            )

        summary = {

            "passport_pages": passport_pages,

            "non_passport_pages": non_passport_pages,

            "selected_page": best_page,

            "overall_status":

                "PASSPORT_DETECTED"

                if passport_pages

                else "NO_PASSPORT_FOUND",

            "ready_for_authenticity_checks":

                passport_pages > 0

        }

        if best_page is None:

            return {

                "summary": summary,

                "pages": pages

            }

        selected = pages[best_page - 1]

        print("\n=========== SELECTED PAGE ===========")
        print(selected["document"])
        print("=====================================\n")

        authenticity = AuthenticityEngine().verify(

            image_path=selected["image"],

            mrz_validation=selected["mrz"]["validation"],

            field_consistency=selected["fields"]["consistency"],

            quality_result=selected["quality"]

        )

        print("\n======= AUTHENTICITY RESULT =========")
        print(authenticity)
        print("=====================================\n")

        forgery = ForgeryEngine().analyze(

            selected["image"]

        )

        print("\n========= FORGERY RESULT ============")
        print(forgery)
        print("=====================================\n")

        decision = DecisionEngine().evaluate(

            mrz_result=selected["mrz"]["validation"],

            authenticity_result=authenticity,

            forgery_result=forgery

        )

        print("\n========== FINAL DECISION ==========")
        print(decision)
        print("====================================\n")

        return VerificationReport.generate(

            request_id="",

            document_type=selected["document"]["document_type"],

            authenticity_result=authenticity,

            forgery_result=forgery,

            decision_result=decision

        )
