﻿from src.documents.passport.verification.decision.confidence_engine import ConfidenceEngine
from src.documents.passport.verification.decision.risk_engine import RiskEngine


class DecisionEngine:
    """
    Final verification decision.

    Uses MRZ validation, authenticity score, forgery score,
    confidence, and risk to determine the final decision.
    """

    def evaluate(
        self,
        mrz_result,
        authenticity_result,
        forgery_result
    ):

        confidence = ConfidenceEngine.calculate(
            mrz_result=mrz_result,
            authenticity_result=authenticity_result,
            forgery_result=forgery_result
        )

        risk = RiskEngine.calculate(
            confidence_result=confidence,
            authenticity_result=authenticity_result,
            forgery_result=forgery_result
        )

        authenticity_score = authenticity_result["authenticity"]["score"]
        forgery_score = forgery_result["summary"]["score"]

        mrz_valid = (
            mrz_result.get("valid", False)
            or
            mrz_result.get("passed", False)
        )

        # ---------------------------------
        # Decision Rules
        # ---------------------------------

        if (
            mrz_valid
            and authenticity_score >= 85
            and forgery_score <= 20
        ):

            decision = "GENUINE"

        elif (
            mrz_valid
            and authenticity_score >= 70
            and forgery_score <= 40
        ):

            decision = "LIKELY_GENUINE"

        elif forgery_score >= 80:

            decision = "LIKELY_FAKE"

        else:

            decision = "SUSPICIOUS"

        warnings = []

        warnings.extend(
            authenticity_result["authenticity"].get(
                "reasons",
                []
            )
        )

        warnings.extend(
            forgery_result["summary"].get(
                "warnings",
                []
            )
        )

        return {

            "passed": decision in (
                "GENUINE",
                "LIKELY_GENUINE"
            ),

            "decision": decision,

            "confidence": confidence["score"],

            "risk": risk["level"],

            "authenticity_score": authenticity_score,

            "forgery_score": forgery_score,

            "warnings": warnings

        }
