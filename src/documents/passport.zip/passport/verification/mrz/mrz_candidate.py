﻿import re


class MRZCandidate:
    """
    Finds ICAO TD3 MRZ candidates from OCR output.

    Handles:
    - OCR returned as one paragraph
    - OCR returned as list of lines
    - Broken MRZ lines
    - Lowercase OCR
    """

    MIN_LENGTH = 20

    @staticmethod
    def clean_line(text: str):

        text = text.upper()

        text = text.replace(" ", "")

        text = text.replace("|", "<")
        text = text.replace("Â«", "<")
        text = text.replace(">", "<")

        text = re.sub(
            r"[^A-Z0-9<]",
            "",
            text
        )

        return text

    @classmethod
    def find(cls, ocr_text):

        # ---------------------------------------
        # Convert OCR output into candidate lines
        # ---------------------------------------

        if isinstance(ocr_text, str):

            raw_lines = re.split(
                r"[\r\n]+",
                ocr_text
            )

            # OCR sometimes returns the whole page
            # in one line.
            if len(raw_lines) == 1:

                raw_lines = re.findall(

                    r"P<[A-Z0-9<]{15,}|[A-Z0-9<]{30,}",

                    ocr_text.upper()

                )

        else:

            raw_lines = ocr_text

        candidates = []

        for line in raw_lines:

            cleaned = cls.clean_line(line)

            if "<" not in cleaned:
                continue

            if len(cleaned) < cls.MIN_LENGTH:
                continue

            candidates.append(cleaned)

        # ---------------------------------------
        # Merge broken lines
        # ---------------------------------------

        merged = []

        current = ""

        for line in candidates:

            if current == "":

                current = line

                continue

            if len(current) < 44:

                current += line

            else:

                merged.append(current)

                current = line

        if current:

            merged.append(current)

        # ---------------------------------------
        # Split oversized candidates
        # ---------------------------------------

        final = []

        for line in merged:

            if line.startswith("P<") and len(line) >= 88:

                final.append(line[:44])

                final.append(line[44:88])

            else:

                final.append(line)

        # ---------------------------------------
        # Keep best MRZ lines
        # ---------------------------------------

        final = [

            line

            for line in final

            if len(line) >= 30

        ]

        if len(final) >= 2:

            return final[-2:]

        return final
