﻿from src.documents.passport.verification.mrz.mrz_candidate import MRZCandidate
from src.documents.passport.verification.mrz.mrz_corrector import MRZCorrector


class MRZParser:
    """
    ICAO 9303 TD3 Passport MRZ Parser
    """

    MRZ_LINE_LENGTH = 44

    @classmethod
    def parse(cls, ocr_lines):

        mrz_lines = MRZCandidate.find(ocr_lines)

        if len(mrz_lines) < 2:
            return {
                "detected": False,
                "parsed": False,
                "confidence": 0.0,
                "reason": "Unable to locate two MRZ lines."
            }

        # ----------------------------
        # Normalize
        # ----------------------------

        line1 = cls.normalize_line(mrz_lines[0])
        line2 = cls.normalize_line(mrz_lines[1])

        # ----------------------------
        # OCR correction
        # ----------------------------

        line1, line2 = MRZCorrector.correct(
            line1,
            line2
        )

        # ----------------------------
        # Validate format
        # ----------------------------

        if not line1.startswith("P<"):

            return {

                "detected": True,

                "parsed": False,

                "confidence": 0.15,

                "reason": "MRZ line 1 is not a TD3 passport format."

            }

        if len(line1) != cls.MRZ_LINE_LENGTH:

            return {

                "detected": True,

                "parsed": False,

                "confidence": 0.25,

                "reason": f"MRZ line 1 length = {len(line1)}"

            }

        if len(line2) != cls.MRZ_LINE_LENGTH:

            return {

                "detected": True,

                "parsed": False,

                "confidence": 0.25,

                "reason": f"MRZ line 2 length = {len(line2)}"

            }

        surname, given_names = cls.parse_names(line1)

        passport_number = line2[0:9].replace("<", "")

        nationality = line2[10:13]

        birth_date = line2[13:19]

        expiry_date = line2[21:27]

        gender = line2[20]

        confidence = cls.compute_confidence(
            line1,
            line2
        )

        return {

            "detected": True,

            "parsed": True,

            "confidence": confidence,

            "line1": line1,

            "line2": line2,

            "document_type": line1[0],

            "document_subtype": line1[1],

            "issuing_country": line1[2:5],

            "surname": surname,

            "given_names": given_names,

            "passport_number": passport_number,

            "passport_number_check": line2[9],

            "nationality": nationality,

            "birth_date": birth_date,

            "birth_date_check": line2[19],

            "gender": gender,

            "expiry_date": expiry_date,

            "expiry_date_check": line2[27],

            "personal_number": line2[28:42],

            "personal_number_check": line2[42],

            "final_check": line2[43]
        }

    @classmethod
    def normalize_line(cls, line: str):

        line = line.upper().strip()

        line = line.replace(" ", "")
        line = line.replace("|", "<")
        line = line.replace("Â«", "<")
        line = line.replace(">", "<")

        if len(line) > cls.MRZ_LINE_LENGTH:
            line = line[:cls.MRZ_LINE_LENGTH]

        if len(line) < cls.MRZ_LINE_LENGTH:
            line += "<" * (
                cls.MRZ_LINE_LENGTH - len(line)
            )

        return line

    @staticmethod
    def parse_names(line1):

        names = line1[5:]

        if "<<" in names:

            surname, given = names.split("<<", 1)

        else:

            surname = names

            given = ""

        surname = surname.replace("<", " ").strip()

        given = given.replace("<", " ").strip()

        return surname, given

    @staticmethod
    def compute_confidence(line1, line2):

        score = 100

        if not line1.startswith("P<"):
            score -= 30

        score -= line1.count("?") * 2
        score -= line2.count("?") * 2

        score -= line1.count("*") * 2
        score -= line2.count("*") * 2

        score = max(0, score)

        return round(score / 100, 2)
