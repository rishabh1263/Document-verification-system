﻿import cv2


class QualityChecker:
    MIN_BLUR_SCORE = 40.0
    MIN_BRIGHTNESS = 40
    MAX_BRIGHTNESS = 250
    MIN_WIDTH = 600
    MIN_HEIGHT = 600

    @classmethod
    def check(cls, image_path: str):

        image = cv2.imread(image_path)

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        blur_score = cv2.Laplacian(gray, cv2.CV_64F).var()

        brightness = gray.mean()

        height, width = gray.shape

        blur_pass = blur_score >= cls.MIN_BLUR_SCORE

        brightness_pass = (
            cls.MIN_BRIGHTNESS <= brightness <= cls.MAX_BRIGHTNESS
        )

        resolution_pass = (
            width >= cls.MIN_WIDTH and
            height >= cls.MIN_HEIGHT
        )

        passed = (
            blur_pass and
            brightness_pass and
            resolution_pass
        )

        return {
            "passed": bool(passed),
            "blur": {
                "score": round(float(blur_score), 2),
                "passed": bool(blur_pass)
            },
            "brightness": {
                "score": round(float(brightness), 2),
                "passed": bool(brightness_pass)
            },
            "resolution": {
                "width": int(width),
                "height": int(height),
                "passed": bool(resolution_pass)
            }
        }
