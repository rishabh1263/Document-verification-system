﻿from pathlib import Path

import cv2


class ImageNormalizer:

    @staticmethod
    def normalize(image_path: str, output_folder: str):

        image = cv2.imread(image_path)

        output_path = (
            Path(output_folder)
            / f"{Path(image_path).stem}.png"
        )

        cv2.imwrite(str(output_path), image)

        return str(output_path)
