﻿import cv2
from pathlib import Path


class ImageEnhancer:

    @staticmethod
    def enhance(image_path: str, output_folder: str):

        image = cv2.imread(image_path)

        if image is None:
            raise ValueError("Unable to load image.")

        # Denoise
        image = cv2.fastNlMeansDenoisingColored(
            image,
            None,
            5,
            5,
            7,
            21
        )

        # Contrast Enhancement (CLAHE)
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)

        l, a, b = cv2.split(lab)

        clahe = cv2.createCLAHE(
            clipLimit=2.0,
            tileGridSize=(8, 8)
        )

        l = clahe.apply(l)

        enhanced = cv2.merge((l, a, b))

        enhanced = cv2.cvtColor(
            enhanced,
            cv2.COLOR_LAB2BGR
        )

        output = (
            Path(output_folder)
            / f"{Path(image_path).stem}_enhanced.png"
        )

        cv2.imwrite(str(output), enhanced)

        return str(output)
