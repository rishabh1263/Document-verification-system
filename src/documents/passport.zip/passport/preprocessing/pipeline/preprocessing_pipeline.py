﻿from pathlib import Path

from src.documents.passport.preprocessing.converter.pdf_converter import PDFConverter
from src.documents.passport.preprocessing.normalizer.image_normalizer import ImageNormalizer
from src.documents.passport.preprocessing.normalizer.image_enhancer import ImageEnhancer
from src.documents.passport.preprocessing.quality.quality_checker import QualityChecker


class PreprocessingPipeline:

    @staticmethod
    def process(file_path: str):
        processed_folder = "storage/processed"

        extension = Path(file_path).suffix.lower()

        if extension == ".pdf":
            pages = PDFConverter.convert(
                file_path,
                processed_folder
            )

            images = []

            for page in pages:
                enhanced = ImageEnhancer.enhance(
                    page,
                    processed_folder
                )
                images.append(enhanced)

        else:
            normalized = ImageNormalizer.normalize(
                file_path,
                processed_folder
            )

            enhanced = ImageEnhancer.enhance(
                normalized,
                processed_folder
            )

            images = [enhanced]

        quality_results = []

        for image in images:
            quality_results.append(
                QualityChecker.check(image)
            )

        return {
            "processed_images": images,
            "quality": quality_results
        }
