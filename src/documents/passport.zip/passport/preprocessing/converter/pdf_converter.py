﻿import fitz
from pathlib import Path


class PDFConverter:

    @staticmethod
    def convert(pdf_path: str, output_folder: str):

        pdf = fitz.open(pdf_path)

        images = []

        Path(output_folder).mkdir(parents=True, exist_ok=True)

        for page_number in range(len(pdf)):

            page = pdf.load_page(page_number)

            pix = page.get_pixmap(dpi=300)

            image_path = (
                Path(output_folder)
                / f"{Path(pdf_path).stem}_page_{page_number + 1}.png"
            )

            pix.save(str(image_path))

            images.append(str(image_path))

        pdf.close()

        return images
