"""
page1_metadata_extractor.py

Bank Statement V2
Phase 1 - Generic Page-1 Metadata Extraction V4.2

V4.2:
- Keeps V4.1 SBI OCR protections.
- Adds conservative structural account-holder fallback for layouts where
  the holder name is a standalone header line near the statement period
  and before CRN/CIF/account identity metadata.
- No bank-specific conditions.
- Null is preferred over an unsafe guess.
"""

from __future__ import annotations

import calendar
import re

from dataclasses import asdict, dataclass
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Sequence, Tuple


# ============================================================
# RESULT MODEL
# ============================================================


@dataclass
class ExtractedField:
    value: Any = None
    confidence: float = 0.0
    source: Optional[str] = None
    evidence: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ============================================================
# GENERIC ALIASES
# ============================================================


FIELD_ALIASES: Dict[str, Sequence[str]] = {
    "account_holder_name": (
        "account holder name",
        "name of account holder",
        "primary account holder",
        "account holder",
        "customer name",
        "account name",
    ),

    "account_number": (
        "account number",
        "account no.",
        "account no",
        "a/c number",
        "a/c no.",
        "a/c no",
        "a/c",
        "ac number",
        "ac no.",
        "ac no",
        "acct number",
        "acct no.",
        "acct no",
        "acct",
    ),

    "ifsc": (
        "ifsc code",
        "ifsc",
        "ifs code",
    ),

    "branch": (
        "branch name",
        "home branch",
        "base branch",
    ),

    "branch_code": (
        "branch code",
        "branch id",
        "branch identifier",
        "sol id",
        "sol code",
    ),

    "account_type": (
        "account type",
        "type of account",
        "account scheme",
        "scheme type",
        "product type",
        "account product",
        "scheme",
    ),

    "customer_id": (
        "customer id",
        "customer number",
        "customer no.",
        "customer no",
        "cust id",
        "cust number",
        "cust no.",
        "cust no",
        "cif id",
        "cif number",
        "cif no.",
        "cif no",
        "cif",
        "crn number",
        "crn no.",
        "crn no",
        "crn",
        "client id",
        "relationship number",
        "relationship no",
    ),
}


EXTRA_BOUNDARY_LABELS: Sequence[str] = (
    "branch email",
    "branch e-mail",
    "branch mail",
    "branch phone number",
    "branch phone",
    "branch code",
    "phone number",
    "phone",
    "mobile number",
    "mobile no",
    "mobile",
    "email address",
    "email id",
    "email",
    "account status",
    "nominee registered",
    "nominee",
    "currency",
    "micr code",
    "micr",
    "address",
    "statement period",
    "statement from",
    "statement generated on",
    "statement generated",
    "generated on",
    "date of statement",
    "time of statement",
    "opening balance",
    "closing balance",
    "product",
    "interest rate",
    "drawing power",
)


def _all_boundary_aliases() -> Tuple[str, ...]:
    values: List[str] = []

    for aliases in FIELD_ALIASES.values():
        values.extend(aliases)

    values.extend(EXTRA_BOUNDARY_LABELS)
    values.append("name")

    return tuple(
        sorted(
            set(values),
            key=len,
            reverse=True,
        )
    )


ALL_BOUNDARY_ALIASES = _all_boundary_aliases()


# ============================================================
# DATE PATTERNS
# ============================================================


MONTH_PATTERN = r"""
(?:
    jan(?:uary)?
    |
    feb(?:ruary)?
    |
    mar(?:ch)?
    |
    apr(?:il)?
    |
    may
    |
    jun(?:e)?
    |
    jul(?:y)?
    |
    aug(?:ust)?
    |
    sep(?:t(?:ember)?)?
    |
    oct(?:ober)?
    |
    nov(?:ember)?
    |
    dec(?:ember)?
)
"""


DATE_TOKEN = rf"""
(?:
    \d{{1,2}}[./-]\d{{1,2}}[./-]\d{{2,4}}
    |
    \d{{4}}[./-]\d{{1,2}}[./-]\d{{1,2}}
    |
    \d{{1,2}}
    (?:st|nd|rd|th)?
    [\s./-]+
    {MONTH_PATTERN}
    [\s,./-]+
    \d{{2,4}}
    |
    {MONTH_PATTERN}
    [\s./-]+
    \d{{1,2}}
    (?:st|nd|rd|th)?
    [\s,./-]+
    \d{{2,4}}
)
"""


# ============================================================
# UTILITIES
# ============================================================


def _clean_value(value: Optional[str]) -> Optional[str]:
    if not value:
        return None

    value = re.sub(
        r"[ \t]+",
        " ",
        value.strip(),
    )

    value = value.strip(" \t:-=|")

    return value or None


def _compact_identifier(value: str) -> str:
    return re.sub(
        r"[\s\-]",
        "",
        value,
    )


def _evidence(
    text: str,
    start: int,
    end: int,
    radius: int = 55,
) -> str:
    left = max(0, start - radius)
    right = min(len(text), end + radius)

    return re.sub(
        r"\s+",
        " ",
        text[left:right],
    ).strip()


def _alias_to_regex(alias: str) -> str:
    escaped = re.escape(alias)

    return escaped.replace(
        r"\ ",
        r"\s*",
    )


def _compile_alias_pattern(
    aliases: Sequence[str],
) -> str:
    aliases = sorted(
        aliases,
        key=len,
        reverse=True,
    )

    return (
        "(?:"
        + "|".join(
            _alias_to_regex(alias)
            for alias in aliases
        )
        + ")"
    )


def _boundary_pattern(
    excluded_aliases: Optional[Sequence[str]] = None,
) -> str:
    excluded = {
        alias.lower()
        for alias in (excluded_aliases or ())
    }

    aliases = [
        alias
        for alias in ALL_BOUNDARY_ALIASES
        if alias.lower() not in excluded
    ]

    return _compile_alias_pattern(aliases)


def _header_text(
    text: str,
    max_lines: int = 60,
    max_chars: int = 8000,
) -> str:
    return "\n".join(
        text.splitlines()[:max_lines]
    )[:max_chars]


def _normalized_word(value: str) -> str:
    return re.sub(
        r"[^a-z]",
        "",
        value.lower(),
    )


def _edit_distance_leq_one(
    left: str,
    right: str,
) -> bool:
    left = _normalized_word(left)
    right = _normalized_word(right)

    if left == right:
        return True

    if abs(len(left) - len(right)) > 1:
        return False

    if len(left) == len(right):
        differences = sum(
            a != b
            for a, b in zip(left, right)
        )

        return differences <= 1

    if len(left) > len(right):
        left, right = right, left

    i = 0
    j = 0
    edits = 0

    while i < len(left) and j < len(right):
        if left[i] == right[j]:
            i += 1
            j += 1
            continue

        edits += 1

        if edits > 1:
            return False

        j += 1

    return True


# ============================================================
# IDENTIFIER VALIDATION
# ============================================================


class IdentifierValidator:

    @staticmethod
    def valid_account_number(value: str) -> bool:
        value = _compact_identifier(value).upper()

        if not (6 <= len(value) <= 24):
            return False

        if not re.fullmatch(
            r"[0-9X*]+",
            value,
        ):
            return False

        if not re.search(r"\d", value):
            return False

        return True

    @staticmethod
    def valid_customer_id(value: str) -> bool:
        value = value.strip().upper()

        if not (3 <= len(value) <= 32):
            return False

        if not re.fullmatch(
            r"[A-Z0-9X*/_\-]+",
            value,
        ):
            return False

        if not re.search(
            r"[\dX*]",
            value,
        ):
            return False

        return True


# ============================================================
# IFSC
# ============================================================


class IFSCExtractor:

    STRICT_IFSC = re.compile(
        r"(?<![A-Z0-9])"
        r"([A-Z]{4}\s*0\s*[A-Z0-9]{6})"
        r"(?![A-Z0-9])",
        re.IGNORECASE,
    )

    @classmethod
    def extract(cls, text: str) -> ExtractedField:
        alias_pattern = _compile_alias_pattern(
            FIELD_ALIASES["ifsc"]
        )

        labeled_pattern = rf"""
        (?P<label>{alias_pattern})
        \s*
        (?::|=|-)?
        \s*
        (?P<value>
            [A-Za-z]{{4}}
            \s*
            0
            \s*
            [A-Za-z0-9]{{6}}
        )
        """

        match = re.search(
            labeled_pattern,
            text,
            flags=re.IGNORECASE | re.VERBOSE,
        )

        if match:
            value = re.sub(
                r"\s+",
                "",
                match.group("value"),
            ).upper()

            if re.fullmatch(
                r"[A-Z]{4}0[A-Z0-9]{6}",
                value,
            ):
                return ExtractedField(
                    value=value,
                    confidence=0.99,
                    source="label_alias+ifsc_structure",
                    evidence=_evidence(
                        text,
                        match.start(),
                        match.end(),
                    ),
                )

        match = cls.STRICT_IFSC.search(text)

        if match:
            value = re.sub(
                r"\s+",
                "",
                match.group(1),
            ).upper()

            return ExtractedField(
                value=value,
                confidence=0.82,
                source="ifsc_structure",
                evidence=_evidence(
                    text,
                    match.start(),
                    match.end(),
                ),
            )

        return ExtractedField()


# ============================================================
# ACCOUNT NUMBER
# ============================================================


class AccountNumberExtractor:

    @classmethod
    def extract(cls, text: str) -> ExtractedField:
        header = _header_text(text)

        alias_pattern = _compile_alias_pattern(
            FIELD_ALIASES["account_number"]
        )

        pattern = rf"""
        (?P<label>{alias_pattern})
        \s*
        (?::|=|-)?
        \s*
        (?P<value>
            [0-9Xx*]
            [0-9Xx*\s\-]{{4,30}}
            [0-9Xx*]
        )
        """

        for match in re.finditer(
            pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            raw_value = match.group(
                "value"
            ).split("\n", 1)[0]

            value = _compact_identifier(
                raw_value
            ).upper()

            if not IdentifierValidator.valid_account_number(
                value
            ):
                continue

            masked = bool(
                re.search(r"[X*]", value)
            )

            return ExtractedField(
                value=value,
                confidence=0.95 if masked else 0.97,
                source=(
                    "label_alias+masked_account_structure"
                    if masked
                    else "label_alias+account_structure"
                ),
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        # OCR multiline fallback
        lines = header.splitlines()

        alias_line_pattern = re.compile(
            rf"^\s*{alias_pattern}\s*:?\s*$",
            re.IGNORECASE,
        )

        for index, line in enumerate(lines):
            if not alias_line_pattern.search(line):
                continue

            for offset in range(1, 4):
                target_index = index + offset

                if target_index >= len(lines):
                    break

                candidate_line = lines[
                    target_index
                ].strip()

                if not candidate_line:
                    continue

                candidate = re.sub(
                    r"^[\s:=\-]+",
                    "",
                    candidate_line,
                )

                candidate = _compact_identifier(
                    candidate
                ).upper()

                if IdentifierValidator.valid_account_number(
                    candidate
                ):
                    evidence = " ".join(
                        lines[
                            index:
                            target_index + 1
                        ]
                    )

                    return ExtractedField(
                        value=candidate,
                        confidence=0.90,
                        source="account_label+ocr_multiline_structure",
                        evidence=evidence,
                    )

        return ExtractedField()


# ============================================================
# CUSTOMER ID
# ============================================================


class CustomerIDExtractor:

    @classmethod
    def extract(cls, text: str) -> ExtractedField:
        header = _header_text(text)

        alias_pattern = _compile_alias_pattern(
            FIELD_ALIASES["customer_id"]
        )

        pattern = rf"""
        (?P<label>{alias_pattern})
        \s*
        (?::|=|-)?
        \s*
        (?P<value>
            [A-Za-z0-9Xx*]
            [A-Za-z0-9Xx*/_\-]{{2,30}}
        )
        """

        for match in re.finditer(
            pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            value = (
                match.group("value")
                .strip()
                .upper()
            )

            if not IdentifierValidator.valid_customer_id(
                value
            ):
                continue

            return ExtractedField(
                value=value,
                confidence=0.96,
                source="customer_identifier_label",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        # OCR bounded multiline fallback
        lines = header.splitlines()

        alias_line_pattern = re.compile(
            rf"^\s*{alias_pattern}\s*:?\s*$",
            re.IGNORECASE,
        )

        for index, line in enumerate(lines):
            if not alias_line_pattern.search(line):
                continue

            for offset in range(1, 5):
                target_index = index + offset

                if target_index >= len(lines):
                    break

                candidate_line = lines[
                    target_index
                ].strip()

                if not candidate_line:
                    continue

                candidate = re.sub(
                    r"^[\s:=\-]+",
                    "",
                    candidate_line,
                )

                candidate = (
                    candidate
                    .split()[0]
                    .strip()
                    .upper()
                )

                if not IdentifierValidator.valid_customer_id(
                    candidate
                ):
                    continue

                evidence = " ".join(
                    lines[
                        index:
                        target_index + 1
                    ]
                )

                return ExtractedField(
                    value=candidate,
                    confidence=0.88,
                    source="customer_identifier_label+ocr_multiline_structure",
                    evidence=evidence,
                )

        return ExtractedField()


# ============================================================
# BRANCH CODE
# ============================================================


class BranchCodeExtractor:

    @classmethod
    def extract(cls, text: str) -> ExtractedField:
        header = _header_text(text)

        alias_pattern = _compile_alias_pattern(
            FIELD_ALIASES["branch_code"]
        )

        pattern = rf"""
        (?P<label>{alias_pattern})
        \s*
        (?::|=|-)?
        \s*
        (?P<value>
            [A-Za-z0-9]
            [A-Za-z0-9/_\-]{{1,20}}
        )
        """

        for match in re.finditer(
            pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            value = (
                match.group("value")
                .strip()
                .upper()
            )

            if not re.fullmatch(
                r"[A-Z0-9][A-Z0-9/_\-]{1,20}",
                value,
            ):
                continue

            return ExtractedField(
                value=value,
                confidence=0.95,
                source="branch_code_label",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        lines = header.splitlines()

        alias_line_pattern = re.compile(
            rf"^\s*{alias_pattern}\s*:?\s*$",
            re.IGNORECASE,
        )

        for index, line in enumerate(lines):
            if not alias_line_pattern.search(line):
                continue

            for offset in range(1, 3):
                target_index = index + offset

                if target_index >= len(lines):
                    break

                candidate = re.sub(
                    r"^[\s:=\-]+",
                    "",
                    lines[target_index].strip(),
                )

                if re.fullmatch(
                    r"[A-Za-z0-9][A-Za-z0-9/_\-]{1,20}",
                    candidate,
                ):
                    return ExtractedField(
                        value=candidate.upper(),
                        confidence=0.91,
                        source="branch_code_label+ocr_multiline",
                        evidence=" ".join(
                            lines[
                                index:
                                target_index + 1
                            ]
                        ),
                    )

        return ExtractedField()


# ============================================================
# BRANCH NAME
# ============================================================


class BranchExtractor:

    INVALID_METADATA_WORDS = (
        "email",
        "mail",
        "phone",
        "mobile",
        "code",
        "id",
        "identifier",
        "address",
        "contact",
        "fax",
        "number",
    )

    @classmethod
    def _looks_like_metadata_word(
        cls,
        value: str,
    ) -> bool:
        cleaned = _clean_value(value)

        if not cleaned:
            return True

        words = re.findall(
            r"[A-Za-z]+",
            cleaned,
        )

        if not words:
            return False

        if len(words) > 2:
            return False

        for word in words:
            for invalid in cls.INVALID_METADATA_WORDS:
                if _edit_distance_leq_one(
                    word,
                    invalid,
                ):
                    return True

        return False

    @classmethod
    def extract(cls, text: str) -> ExtractedField:
        header = _header_text(text)

        alias_pattern = _compile_alias_pattern(
            FIELD_ALIASES["branch"]
        )

        boundary = _boundary_pattern(
            excluded_aliases=FIELD_ALIASES["branch"]
        )

        pattern = rf"""
        (?P<label>{alias_pattern})
        \s*
        (?::|=|-)?
        \s*
        (?P<value>
            [A-Za-z0-9]
            [A-Za-z0-9 .,'&()/_\-]{{0,100}}?
        )
        (?=
            \s*(?:{boundary})\b
            |
            \n
            |
            $
        )
        """

        for match in re.finditer(
            pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            value = _clean_value(
                match.group("value")
            )

            if not value:
                continue

            if cls._looks_like_metadata_word(
                value
            ):
                continue

            return ExtractedField(
                value=value,
                confidence=0.95,
                source="branch_name_label",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        # Bare Branch fallback
        bare_pattern = rf"""
        \bbranch\b
        \s*
        (?::|=)?
        \s*
        (?P<value>
            [A-Za-z0-9]
            [A-Za-z0-9 .,'&()/_\-]{{0,100}}?
        )
        (?=
            \s*(?:{boundary})\b
            |
            \n
            |
            $
        )
        """

        for match in re.finditer(
            bare_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            value = _clean_value(
                match.group("value")
            )

            if not value:
                continue

            if cls._looks_like_metadata_word(
                value
            ):
                continue

            first_word_match = re.match(
                r"[A-Za-z]+",
                value,
            )

            if first_word_match:
                first_word = first_word_match.group(0)

                rejected = any(
                    _edit_distance_leq_one(
                        first_word,
                        invalid,
                    )
                    for invalid
                    in cls.INVALID_METADATA_WORDS
                )

                if rejected:
                    continue

            return ExtractedField(
                value=value,
                confidence=0.90,
                source="branch_label",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        return ExtractedField()


# ============================================================
# ACCOUNT TYPE
# ============================================================


class AccountTypeExtractor:

    ACCOUNT_TYPE_PATTERNS: Sequence[
        Tuple[str, str]
    ] = (
        (
            r"\bsavings?\s+(?:bank\s+)?account\b",
            "Savings",
        ),
        (
            r"\bsavings?\b",
            "Savings",
        ),
        (
            r"\bcurrent\s+account\b",
            "Current",
        ),
        (
            r"\bcurrent\b",
            "Current",
        ),
        (
            r"\bsalary\s+account\b",
            "Salary",
        ),
        (
            r"\bsalary\b",
            "Salary",
        ),
        (
            r"\boverdraft\b",
            "Overdraft",
        ),
        (
            r"\bcash\s+credit\b",
            "Cash Credit",
        ),
        (
            r"\bnre\b",
            "NRE",
        ),
        (
            r"\bnro\b",
            "NRO",
        ),
    )

    @classmethod
    def extract(cls, text: str) -> ExtractedField:
        header = _header_text(text)

        alias_pattern = _compile_alias_pattern(
            FIELD_ALIASES["account_type"]
        )

        boundary = _boundary_pattern(
            excluded_aliases=FIELD_ALIASES[
                "account_type"
            ]
        )

        labeled_pattern = rf"""
        (?P<label>{alias_pattern})
        \s*
        (?::|=|-)?
        \s*
        (?P<value>
            [A-Za-z0-9]
            [A-Za-z0-9 .,&()/_\-]{{0,80}}?
        )
        (?=
            \s*(?:{boundary})\b
            |
            \n
            |
            $
        )
        """

        match = re.search(
            labeled_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        )

        if match:
            raw_value = _clean_value(
                match.group("value")
            )

            if raw_value:
                for pattern, canonical in (
                    cls.ACCOUNT_TYPE_PATTERNS
                ):
                    if re.search(
                        pattern,
                        raw_value,
                        flags=re.IGNORECASE,
                    ):
                        return ExtractedField(
                            value=canonical,
                            confidence=0.96,
                            source="account_type_label+semantic_type",
                            evidence=_evidence(
                                header,
                                match.start(),
                                match.end(),
                            ),
                        )

                return ExtractedField(
                    value=raw_value,
                    confidence=0.87,
                    source="account_type_label",
                    evidence=_evidence(
                        header,
                        match.start(),
                        match.end(),
                    ),
                )

        for pattern, canonical in (
            cls.ACCOUNT_TYPE_PATTERNS
        ):
            match = re.search(
                pattern,
                header,
                flags=re.IGNORECASE,
            )

            if match:
                return ExtractedField(
                    value=canonical,
                    confidence=0.65,
                    source="account_type_header_keyword",
                    evidence=_evidence(
                        header,
                        match.start(),
                        match.end(),
                    ),
                )

        return ExtractedField()


# ============================================================
# ACCOUNT HOLDER V4.2
# ============================================================


class AccountHolderExtractor:

    INVALID_NAME_WORDS = {
        "statement",
        "account",
        "branch",
        "bank",
        "customer",
        "currency",
        "nominee",
        "nomine",
        "registered",
        "active",
        "savings",
        "current",
        "phone",
        "address",
        "ifsc",
        "code",
        "email",
        "product",
        "balance",
        "bal",
        "period",
        "from",
        "to",
        "date",
        "transactions",
        "transaction",
        "opening",
        "closing",
        "debit",
        "credit",
        "withdrawal",
        "deposit",
        "description",
        "particulars",
        "reference",
        "cheque",
        "page",
    }

    STRUCTURAL_NEXT_LABELS = (
        "crn",
        "cif",
        "customer id",
        "customer no",
        "customer number",
        "account no",
        "account number",
        "a/c no",
        "a/c number",
        "account type",
        "branch",
        "ifsc",
        "address",
    )

    @classmethod
    def _valid_name(
        cls,
        value: Optional[str],
    ) -> bool:
        if not value:
            return False

        value = value.strip()

        if not (2 <= len(value) <= 80):
            return False

        if re.search(r"\d", value):
            return False

        # Do not allow metadata punctuation-heavy strings.
        if re.search(
            r"[:=@#]",
            value,
        ):
            return False

        words = re.findall(
            r"[A-Za-z]+",
            value,
        )

        if not words:
            return False

        # Keep structural fallback conservative.
        if len(words) > 6:
            return False

        lower_words = {
            word.lower()
            for word in words
        }

        if lower_words & cls.INVALID_NAME_WORDS:
            return False

        letters = sum(
            character.isalpha()
            for character in value
        )

        return letters >= 2

    @classmethod
    def _looks_like_date_line(
        cls,
        line: str,
    ) -> bool:
        return bool(
            re.search(
                DATE_TOKEN,
                line,
                flags=re.IGNORECASE | re.VERBOSE,
            )
        )

    @classmethod
    def _looks_like_identity_line(
        cls,
        line: str,
    ) -> bool:
        pattern = _compile_alias_pattern(
            cls.STRUCTURAL_NEXT_LABELS
        )

        return bool(
            re.search(
                rf"\b{pattern}\b",
                line,
                flags=re.IGNORECASE,
            )
        )

    @classmethod
    def _structural_header_candidate(
        cls,
        header: str,
    ) -> ExtractedField:
        """
        Generic V4.2 fallback.

        Intended layout:

            Account Statement
            01 May 2025 - 01 May 2026
            Vishal
            CRN xxxxxx657

        Requirements:
        - statement context exists nearby
        - preceding line contains a date/range
        - candidate is a clean standalone plausible name
        - following line contains strong identity metadata

        This avoids guessing arbitrary OCR header lines.
        """

        raw_lines = header.splitlines()

        lines: List[
            Tuple[int, str]
        ] = []

        for index, raw_line in enumerate(
            raw_lines
        ):
            cleaned = re.sub(
                r"[ \t]+",
                " ",
                raw_line,
            ).strip()

            if cleaned:
                lines.append(
                    (index, cleaned)
                )

        if len(lines) < 3:
            return ExtractedField()

        for position in range(
            1,
            len(lines) - 1,
        ):
            raw_index, candidate = lines[
                position
            ]

            if not cls._valid_name(
                candidate
            ):
                continue

            previous_index, previous_line = (
                lines[position - 1]
            )

            next_index, next_line = (
                lines[position + 1]
            )

            # Candidate must be structurally adjacent.
            if raw_index - previous_index > 2:
                continue

            if next_index - raw_index > 2:
                continue

            # Previous line must look like a statement date
            # or date range.
            if not cls._looks_like_date_line(
                previous_line
            ):
                continue

            # Next line must look like identity metadata.
            if not cls._looks_like_identity_line(
                next_line
            ):
                continue

            # Statement context must occur shortly before the
            # candidate, not somewhere arbitrarily on Page 1.
            context_start = max(
                0,
                position - 3,
            )

            preceding_context = " ".join(
                line
                for _, line
                in lines[
                    context_start:
                    position
                ]
            )

            if not re.search(
                r"\b(?:"
                r"account\s+statement"
                r"|statement\s+of\s+account"
                r"|bank\s+statement"
                r"|statement"
                r")\b",
                preceding_context,
                flags=re.IGNORECASE,
            ):
                continue

            evidence = " | ".join(
                line
                for _, line
                in lines[
                    max(0, position - 2):
                    min(
                        len(lines),
                        position + 3,
                    )
                ]
            )

            return ExtractedField(
                value=candidate,
                confidence=0.88,
                source="statement_header_structural_name",
                evidence=evidence,
            )

        return ExtractedField()

    @classmethod
    def extract(cls, text: str) -> ExtractedField:
        header = _header_text(text)

        boundary = _boundary_pattern()

        # ----------------------------------------------------
        # Strategy 1:
        # Explicit holder/customer-name aliases.
        # ----------------------------------------------------

        strong_alias = _compile_alias_pattern(
            FIELD_ALIASES["account_holder_name"]
        )

        strong_pattern = rf"""
        (?P<label>{strong_alias})
        \s*
        (?::|=|-)?
        \s*
        (?P<value>
            [A-Za-z]
            [A-Za-z .,'&()/-]{{1,80}}?
        )
        (?=
            \s*(?:{boundary})\b
            |
            \n
            |
            $
        )
        """

        for match in re.finditer(
            strong_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            value = _clean_value(
                match.group("value")
            )

            if not cls._valid_name(value):
                continue

            return ExtractedField(
                value=value,
                confidence=0.96,
                source="account_holder_label",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        # ----------------------------------------------------
        # Strategy 2:
        # Generic bare Name label.
        #
        # Protect against:
        # Branch Name
        # Nominee Name / OCR Nomine Name
        # Father Name
        # Mother Name
        # Spouse Name
        # Guardian Name
        # Beneficiary Name
        # ----------------------------------------------------

        bare_name_pattern = rf"""
        (?<![A-Za-z])

        (?<!Branch\s)
        (?<!Account\s)
        (?<!Customer\s)
        (?<!Holder\s)
        (?<!Nominee\s)
        (?<!Nomine\s)
        (?<!Father\s)
        (?<!Mother\s)
        (?<!Spouse\s)
        (?<!Guardian\s)
        (?<!Beneficiary\s)

        \bName\b

        \s*
        (?::|=|-)?
        \s*

        (?P<value>
            [A-Za-z]
            [A-Za-z .,'&()/-]{{1,80}}?
        )

        (?=
            \s*(?:{boundary})\b
            |
            \n
            |
            $
        )
        """

        for match in re.finditer(
            bare_name_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            value = _clean_value(
                match.group("value")
            )

            if not cls._valid_name(value):
                continue

            return ExtractedField(
                value=value,
                confidence=0.91,
                source="header_name_label",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        # ----------------------------------------------------
        # Strategy 3:
        # Same-line name immediately before account label.
        #
        # Example:
        # Vishal Account No. 6347393980
        # ----------------------------------------------------

        account_alias = _compile_alias_pattern(
            FIELD_ALIASES["account_number"]
        )

        same_line_pattern = rf"""
        (?:
            ^
            |
            \n
        )
        [ \t]*
        (?P<name>
            [A-Za-z]
            [A-Za-z .,'&()/-]{{1,79}}?
        )
        [ \t]+
        (?P<label>{account_alias})
        \b
        """

        for match in re.finditer(
            same_line_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            value = _clean_value(
                match.group("name")
            )

            if not cls._valid_name(value):
                continue

            return ExtractedField(
                value=value,
                confidence=0.90,
                source="name_before_account_label",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        # ----------------------------------------------------
        # Strategy 4:
        # Previous-line name before account label.
        # ----------------------------------------------------

        previous_line_pattern = rf"""
        (?:
            ^
            |
            \n
        )
        [ \t]*
        (?P<name>
            [A-Za-z]
            [A-Za-z .,'&()/-]{{1,79}}
        )
        [ \t]*
        \n
        [ \t]*
        (?P<label>{account_alias})
        \b
        """

        for match in re.finditer(
            previous_line_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            value = _clean_value(
                match.group("name")
            )

            if not cls._valid_name(value):
                continue

            return ExtractedField(
                value=value,
                confidence=0.87,
                source="name_near_account_label",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        # ----------------------------------------------------
        # Strategy 5 - V4.2
        # Statement-header structural fallback.
        #
        # This comes AFTER labeled strategies.
        # ----------------------------------------------------

        structural = cls._structural_header_candidate(
            header
        )

        if structural.value is not None:
            return structural

        # Never guess arbitrary unlabeled OCR lines.
        return ExtractedField()


# ============================================================
# DATE PARSER
# ============================================================


class GenericDateParser:

    FORMATS = (
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%d.%m.%Y",
        "%d/%m/%y",
        "%d-%m-%y",
        "%d.%m.%y",
        "%Y/%m/%d",
        "%Y-%m-%d",
        "%Y.%m.%d",
        "%d %b %Y",
        "%d %B %Y",
        "%d-%b-%Y",
        "%d-%B-%Y",
        "%d/%b/%Y",
        "%d/%B/%Y",
        "%d.%b.%Y",
        "%d.%B.%Y",
        "%b %d %Y",
        "%B %d %Y",
        "%b-%d-%Y",
        "%B-%d-%Y",
    )

    @classmethod
    def parse(
        cls,
        value: Optional[str],
    ) -> Optional[date]:
        if not value:
            return None

        cleaned = value.strip()

        cleaned = re.sub(
            r"(\d{1,2})(st|nd|rd|th)",
            r"\1",
            cleaned,
            flags=re.IGNORECASE,
        )

        cleaned = cleaned.replace(
            ",",
            " ",
        )

        cleaned = re.sub(
            r"\s+",
            " ",
            cleaned,
        ).strip()

        for fmt in cls.FORMATS:
            try:
                parsed = datetime.strptime(
                    cleaned,
                    fmt,
                ).date()

            except ValueError:
                continue

            if 1990 <= parsed.year <= 2100:
                return parsed

        return None


# ============================================================
# STATEMENT PERIOD
# ============================================================


class StatementPeriodExtractor:

    EXCLUDED_CONTEXT = re.compile(
        r"""
        (?:
            statement\s+generated
            |
            generated\s+on
            |
            print(?:ed)?\s+(?:date|on)
            |
            downloaded\s+on
            |
            date\s+of\s+statement
            |
            time\s+of\s+statement
        )
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    @classmethod
    def _valid_period(
        cls,
        start: Optional[date],
        end: Optional[date],
    ) -> bool:
        if not start or not end:
            return False

        if end < start:
            return False

        if (end - start).days > 366 * 10:
            return False

        return True

    @classmethod
    def _build_fields(
        cls,
        start: date,
        end: date,
        confidence: float,
        source: str,
        evidence: str,
    ) -> Tuple[ExtractedField, ExtractedField]:
        return (
            ExtractedField(
                value=start.isoformat(),
                confidence=confidence,
                source=source,
                evidence=evidence,
            ),
            ExtractedField(
                value=end.isoformat(),
                confidence=confidence,
                source=source,
                evidence=evidence,
            ),
        )

    @classmethod
    def extract(
        cls,
        text: str,
    ) -> Tuple[ExtractedField, ExtractedField]:
        header = _header_text(
            text,
            max_lines=80,
            max_chars=10000,
        )

        # ----------------------------------------------------
        # Strategy 1: explicit statement-period context
        # ----------------------------------------------------

        statement_range_pattern = rf"""
        (?:
            statement\s+period
            |
            for\s+the\s+period
            |
            statement\s+from
            |
            period\s+from
        )

        [\s:=\-]*

        (?P<start>{DATE_TOKEN})

        \s*

        (?:
            to
            |
            till
            |
            until
            |
            through
            |
            thru
            |
            -
            |
            –
            |
            —
        )

        [\s:=\-]*

        (?P<end>{DATE_TOKEN})
        """

        for match in re.finditer(
            statement_range_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            start = GenericDateParser.parse(
                match.group("start")
            )

            end = GenericDateParser.parse(
                match.group("end")
            )

            if not cls._valid_period(
                start,
                end,
            ):
                continue

            return cls._build_fields(
                start=start,
                end=end,
                confidence=0.99,
                source="statement_period_labeled_range",
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        # ----------------------------------------------------
        # Strategy 2: statement context + nearby range
        # ----------------------------------------------------

        statement_near_range = rf"""
        \bstatement\b

        (?:
            [^\n]{{0,50}}
            |
            \n[^\n]{{0,50}}
        )?

        (?P<start>{DATE_TOKEN})

        \s*

        (?:
            to
            |
            till
            |
            until
            |
            through
            |
            thru
            |
            -
            |
            –
            |
            —
        )

        [\s:=\-]*

        (?P<end>{DATE_TOKEN})
        """

        for match in re.finditer(
            statement_near_range,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            context = _evidence(
                header,
                match.start(),
                match.end(),
                radius=20,
            )

            if cls.EXCLUDED_CONTEXT.search(
                context
            ):
                continue

            start = GenericDateParser.parse(
                match.group("start")
            )

            end = GenericDateParser.parse(
                match.group("end")
            )

            if not cls._valid_period(
                start,
                end,
            ):
                continue

            return cls._build_fields(
                start=start,
                end=end,
                confidence=0.95,
                source="statement_context+nearby_date_range",
                evidence=context,
            )

        # ----------------------------------------------------
        # Strategy 3: From DATE To DATE
        # ----------------------------------------------------

        from_to_pattern = rf"""
        \bfrom\b

        [\s:=\-]*

        (?P<start>{DATE_TOKEN})

        \s*

        (?:
            to
            |
            till
            |
            until
            |
            through
            |
            thru
        )

        [\s:=\-]*

        (?P<end>{DATE_TOKEN})
        """

        for match in re.finditer(
            from_to_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            context = _evidence(
                header,
                match.start(),
                match.end(),
            )

            if cls.EXCLUDED_CONTEXT.search(
                context
            ):
                continue

            start = GenericDateParser.parse(
                match.group("start")
            )

            end = GenericDateParser.parse(
                match.group("end")
            )

            if not cls._valid_period(
                start,
                end,
            ):
                continue

            return cls._build_fields(
                start=start,
                end=end,
                confidence=0.94,
                source="from_to_date_range",
                evidence=context,
            )

        # ----------------------------------------------------
        # Strategy 4: unlabelled header date range
        # ----------------------------------------------------

        unlabeled_range_pattern = rf"""
        (?P<start>{DATE_TOKEN})

        \s*

        (?:
            to
            |
            till
            |
            until
            |
            through
            |
            thru
            |
            -
            |
            –
            |
            —
        )

        \s*

        (?P<end>{DATE_TOKEN})
        """

        candidates: List[
            Tuple[int, date, date, re.Match]
        ] = []

        for match in re.finditer(
            unlabeled_range_pattern,
            header,
            flags=re.IGNORECASE | re.VERBOSE,
        ):
            start = GenericDateParser.parse(
                match.group("start")
            )

            end = GenericDateParser.parse(
                match.group("end")
            )

            if not cls._valid_period(
                start,
                end,
            ):
                continue

            context = header[
                max(0, match.start() - 70):
                min(len(header), match.end() + 30)
            ]

            if cls.EXCLUDED_CONTEXT.search(
                context
            ):
                continue

            candidates.append(
                (
                    match.start(),
                    start,
                    end,
                    match,
                )
            )

        if candidates:
            candidates.sort(
                key=lambda item: item[0]
            )

            _, start, end, match = (
                candidates[0]
            )

            preceding = header[
                max(0, match.start() - 150):
                match.start()
            ]

            statement_context = bool(
                re.search(
                    r"\b("
                    r"account\s+statement"
                    r"|statement\s+of\s+account"
                    r"|bank\s+statement"
                    r"|statement"
                    r")\b",
                    preceding,
                    flags=re.IGNORECASE,
                )
            )

            return cls._build_fields(
                start=start,
                end=end,
                confidence=(
                    0.94
                    if statement_context
                    else 0.82
                ),
                source=(
                    "header_date_range+statement_context"
                    if statement_context
                    else "header_date_range"
                ),
                evidence=_evidence(
                    header,
                    match.start(),
                    match.end(),
                ),
            )

        return (
            ExtractedField(),
            ExtractedField(),
        )


# ============================================================
# DURATION
# ============================================================


class StatementDurationCalculator:

    @staticmethod
    def calculate(
        start_date: Optional[str],
        end_date: Optional[str],
    ) -> Tuple[Optional[int], Optional[float]]:
        if not start_date or not end_date:
            return None, None

        try:
            start = date.fromisoformat(
                start_date
            )

            end = date.fromisoformat(
                end_date
            )

        except (ValueError, TypeError):
            return None, None

        if end < start:
            return None, None

        # Inclusive statement duration
        duration_days = (
            end - start
        ).days + 1

        whole_months = (
            (end.year - start.year) * 12
            + end.month
            - start.month
        )

        if end.day >= start.day:
            days_in_end_month = (
                calendar.monthrange(
                    end.year,
                    end.month,
                )[1]
            )

            fraction = (
                end.day - start.day
            ) / days_in_end_month

        else:
            whole_months -= 1

            previous_month = end.month - 1
            previous_year = end.year

            if previous_month == 0:
                previous_month = 12
                previous_year -= 1

            days_in_previous_month = (
                calendar.monthrange(
                    previous_year,
                    previous_month,
                )[1]
            )

            remaining_days = (
                days_in_previous_month
                - start.day
                + end.day
            )

            fraction = (
                remaining_days
                / days_in_previous_month
            )

        duration_months = round(
            max(
                0.0,
                whole_months + fraction,
            ),
            2,
        )

        return (
            duration_days,
            duration_months,
        )


# ============================================================
# BANK NAME
# ============================================================


class BankNameExtractor:

    BANK_TERM = re.compile(
        r"""
        \b
        (?:
            bank
            |
            banking
            |
            small\s+finance\s+bank
            |
            payments\s+bank
        )
        \b
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    INVALID = re.compile(
        r"""
        \b
        (?:
            bank\s+statement
            |
            bank\s+account\s+statement
            |
            account\s+statement
            |
            statement\s+of\s+account
            |
            internet\s+banking
            |
            mobile\s+banking
            |
            banking\s+transactions?
        )
        \b
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    @classmethod
    def extract(cls, text: str) -> ExtractedField:
        header = _header_text(
            text,
            max_lines=30,
            max_chars=4000,
        )

        lines = [
            re.sub(
                r"\s+",
                " ",
                line,
            ).strip()
            for line in header.splitlines()
            if line.strip()
        ]

        candidates: List[
            Tuple[float, int, str]
        ] = []

        for index, line in enumerate(lines):
            if not cls.BANK_TERM.search(line):
                continue

            if cls.INVALID.search(line):
                continue

            if not (4 <= len(line) <= 120):
                continue

            letters = sum(
                character.isalpha()
                for character in line
            )

            if letters < 4:
                continue

            score = 0.70

            score += max(
                0.0,
                0.17 - index * 0.008,
            )

            if re.search(
                r"\b("
                r"limited"
                r"|ltd"
                r"|co-operative"
                r"|cooperative"
                r")\b",
                line,
                flags=re.IGNORECASE,
            ):
                score += 0.05

            if len(line.split()) > 14:
                score -= 0.12

            candidates.append(
                (
                    min(score, 0.94),
                    index,
                    line,
                )
            )

        if not candidates:
            return ExtractedField()

        candidates.sort(
            key=lambda item: (
                -item[0],
                item[1],
            )
        )

        confidence, _, value = candidates[0]

        return ExtractedField(
            value=value,
            confidence=round(
                confidence,
                3,
            ),
            source="page1_text_bank_candidate",
            evidence=value,
        )


# ============================================================
# MAIN EXTRACTOR
# ============================================================


class Page1MetadataExtractor:

    def extract(
        self,
        text: str,
    ) -> Dict[str, Any]:
        text = text or ""

        bank_name = BankNameExtractor.extract(
            text
        )

        account_holder = (
            AccountHolderExtractor.extract(
                text
            )
        )

        account_number = (
            AccountNumberExtractor.extract(
                text
            )
        )

        ifsc = IFSCExtractor.extract(text)

        branch = BranchExtractor.extract(text)

        branch_code = (
            BranchCodeExtractor.extract(
                text
            )
        )

        account_type = (
            AccountTypeExtractor.extract(
                text
            )
        )

        customer_id = (
            CustomerIDExtractor.extract(
                text
            )
        )

        (
            statement_start,
            statement_end,
        ) = StatementPeriodExtractor.extract(
            text
        )

        (
            duration_days,
            duration_months,
        ) = StatementDurationCalculator.calculate(
            statement_start.value,
            statement_end.value,
        )

        if (
            duration_days is not None
            and statement_start.value
            and statement_end.value
        ):
            duration_confidence = min(
                statement_start.confidence,
                statement_end.confidence,
            )

            duration_evidence = (
                f"{statement_start.value}"
                f" -> "
                f"{statement_end.value}"
            )

            duration_source = (
                "calculated_from_statement_dates"
            )

        else:
            duration_confidence = 0.0
            duration_evidence = None
            duration_source = None

        duration_days_field = ExtractedField(
            value=duration_days,
            confidence=duration_confidence,
            source=duration_source,
            evidence=duration_evidence,
        )

        duration_months_field = ExtractedField(
            value=duration_months,
            confidence=duration_confidence,
            source=duration_source,
            evidence=duration_evidence,
        )

        fields = {
            "bank_name":
                bank_name.to_dict(),

            "account_holder_name":
                account_holder.to_dict(),

            "account_number":
                account_number.to_dict(),

            "ifsc":
                ifsc.to_dict(),

            "branch":
                branch.to_dict(),

            "branch_code":
                branch_code.to_dict(),

            "account_type":
                account_type.to_dict(),

            "customer_id":
                customer_id.to_dict(),

            "statement_start_date":
                statement_start.to_dict(),

            "statement_end_date":
                statement_end.to_dict(),

            "statement_duration_days":
                duration_days_field.to_dict(),

            "statement_duration_months":
                duration_months_field.to_dict(),
        }

        fields_extracted = sum(
            1
            for field in fields.values()
            if field["value"] is not None
        )

        confidence_values = [
            field["confidence"]
            for field in fields.values()
            if (
                field["value"] is not None
                and field["confidence"] > 0
            )
        ]

        average_confidence = (
            round(
                sum(confidence_values)
                / len(confidence_values),
                4,
            )
            if confidence_values
            else 0.0
        )

        return {
            "fields": fields,
            "fields_extracted":
                fields_extracted,
            "total_supported_fields":
                len(fields),
            "average_field_confidence":
                average_confidence,
        }


# ============================================================
# SINGLETON
# ============================================================


page1_metadata_extractor = (
    Page1MetadataExtractor()
)