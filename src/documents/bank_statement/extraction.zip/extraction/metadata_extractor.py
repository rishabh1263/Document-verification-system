"""
Generic Bank Statement Metadata Extractor.

Phase 2 - Document Intelligence / Extraction.

Responsibilities:
- extract common bank-statement metadata
- work with native PDF and OCR text
- remain bank-independent
- normalize statement dates
- extract common account identifiers
- preserve missing values rather than inventing metadata
- provide field-level confidence and source evidence

Important:
This module does NOT:
- identify bank-specific templates
- parse transactions
- infer metadata that is not present
- validate transaction arithmetic
- detect tampering
- calculate fraud/risk scores

Expected input:
    normalized statement/header text produced by the Phase 2
    extraction pipeline.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import datetime


# ============================================================
# Result models
# ============================================================


@dataclass(frozen=True)
class MetadataField:
    value: str | None
    confidence: float
    source: str | None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class StatementPeriod:
    start_date: str | None
    end_date: str | None
    confidence: float
    source: str | None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class StatementMetadataResult:
    statement_period: StatementPeriod

    account_number: MetadataField
    account_type: MetadataField

    customer_name: MetadataField

    ifsc: MetadataField
    micr: MetadataField

    branch: MetadataField
    currency: MetadataField

    customer_id: MetadataField

    fields_found: int
    metadata_confidence: float

    def to_dict(self) -> dict:
        return asdict(self)


# ============================================================
# Metadata extractor
# ============================================================


class MetadataExtractor:
    """
    Generic bank-statement metadata extractor.

    Extraction is based on financial-document concepts and
    standardized identifiers rather than bank names.

    Examples of supported concepts:

        Account No
        Account Number
        A/C No
        Statement for A/c
        Customer ID
        CRN
        IFSC
        MICR
        Branch
        Currency
        Statement Period

    No bank-specific template selection is performed.
    """

    # ========================================================
    # Generic date recognition
    # ========================================================

    DATE_TOKEN = (
        r"(?:"

        # 23 Jan 2026
        # 23 January 2026
        r"\d{1,2}\s+"
        r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
        r"[a-z]*\s+\d{2,4}"

        r"|"

        # 23-Jan-2026
        # 23-January-2026
        # 23/Jan/2026
        r"\d{1,2}[\-/]"
        r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
        r"[a-z]*[\-/]\d{2,4}"

        r"|"

        # 23/01/2026
        # 23-01-2026
        # 23.01.2026
        r"\d{1,2}"
        r"[/.\-]"
        r"\d{1,2}"
        r"[/.\-]"
        r"\d{2,4}"

        r"|"

        # 2026-01-23
        # 2026/01/23
        # 2026.01.23
        r"\d{4}"
        r"[/.\-]"
        r"\d{1,2}"
        r"[/.\-]"
        r"\d{1,2}"

        r")"
    )

    PERIOD_PATTERNS = (
        # Statement for A/c XXXXX for the period
        # 23-Jan-2026 to 22-Jul-2026
        #
        # Statement for the period
        # 23-Jan-2026 to 22-Jul-2026
        re.compile(
            rf"(?:statement.*?)?"
            rf"(?:for\s+the\s+period|"
            rf"statement\s*period|"
            rf"period|"
            rf"from)"
            rf"\s*[:\-]?\s*"
            rf"({DATE_TOKEN})"
            rf"\s*(?:to|\-|\u2013|\u2014)\s*"
            rf"({DATE_TOKEN})",
            re.IGNORECASE,
        ),

        # Account Statement01 May 2025 - 01 May 2026
        #
        # Statement 01 May 2025 - 01 May 2026
        re.compile(
            rf"(?:account\s*statement|statement)"
            rf"\s*[:\-]?\s*"
            rf"({DATE_TOKEN})"
            rf"\s*(?:to|\-|\u2013|\u2014)\s*"
            rf"({DATE_TOKEN})",
            re.IGNORECASE,
        ),

        # Generic:
        # 01 May 2025 to 01 May 2026
        re.compile(
            rf"\b({DATE_TOKEN})"
            rf"\s+(?:to|\-|\u2013|\u2014)\s+"
            rf"({DATE_TOKEN})\b",
            re.IGNORECASE,
        ),
    )

    # ========================================================
    # Account number
    # ========================================================

    ACCOUNT_PATTERNS = (
        # Account No 123456789
        # Account Number: 123456789
        # A/C No XXXXX1234
        # A/C Number XXXXX1234
        re.compile(
            r"(?:"
            r"account\s*(?:no|number)"
            r"|"
            r"a\s*/?\s*c\s*(?:no|number)"
            r")"
            r"\.?\s*[:\-]?\s*"
            r"([A-Z0-9Xx*][A-Z0-9Xx*\-]{3,30})",
            re.IGNORECASE,
        ),

        # Statement for A/c XXXXXXXXXX5119
        # Statement for Account XXXXX1234
        re.compile(
            r"(?:statement.*?)"
            r"\b(?:a\s*/?\s*c|account)"
            r"\s*[:\-]?\s*"
            r"([A-Z0-9Xx*][A-Z0-9Xx*\-]{3,30})",
            re.IGNORECASE,
        ),
    )

    # ========================================================
    # Account type
    # ========================================================

    ACCOUNT_TYPE_PATTERNS = (
        re.compile(
            r"(?:"
            r"account\s*type"
            r"|"
            r"type\s*of\s*account"
            r")"
            r"\s*[:\-]?\s*"
            r"([A-Za-z][A-Za-z /&\-]{2,40})",
            re.IGNORECASE,
        ),
    )

    KNOWN_ACCOUNT_TYPES = (
        "savings",
        "saving",
        "current",
        "salary",
        "nre",
        "nro",
        "overdraft",
        "od",
    )

    # ========================================================
    # IFSC
    # ========================================================

    IFSC_PATTERN = re.compile(
        r"\b[A-Z]{4}0[A-Z0-9]{6}\b",
        re.IGNORECASE,
    )

    IFSC_LABEL_PATTERN = re.compile(
        r"(?:IFSC\s*Code|IFSC)"
        r"\s*[:\-]?\s*"
        r"([A-Z]{4}0[A-Z0-9]{6})",
        re.IGNORECASE,
    )

    # ========================================================
    # MICR
    # ========================================================

    MICR_LABEL_PATTERN = re.compile(
        r"(?:MICR\s*Code|MICR)"
        r"\s*[:\-]?\s*"
        r"(\d{9})",
        re.IGNORECASE,
    )

    # ========================================================
    # Branch
    # ========================================================

    BRANCH_PATTERN = re.compile(
        r"(?:branch\s*name|branch)"
        r"\s*[:\-]?\s*"
        r"(.+)",
        re.IGNORECASE,
    )

    # ========================================================
    # Currency
    # ========================================================

    CURRENCY_PATTERN = re.compile(
        r"(?:currency)"
        r"\s*[:\-]?\s*"
        r"([A-Za-z]{3,15}"
        r"(?:\s+[A-Za-z]{3,15})?)",
        re.IGNORECASE,
    )

    CURRENCY_ALIASES = {
        "indian rupee": "INR",
        "indian rupees": "INR",
        "rupee": "INR",
        "rupees": "INR",
        "inr": "INR",

        "usd": "USD",
        "us dollar": "USD",
        "us dollars": "USD",

        "eur": "EUR",
        "euro": "EUR",
        "euros": "EUR",

        "gbp": "GBP",
        "pound": "GBP",
        "pounds": "GBP",
        "pound sterling": "GBP",
    }

    # ========================================================
    # Customer ID
    # ========================================================

    CUSTOMER_ID_PATTERN = re.compile(
        r"(?:"
        r"customer\s*(?:id|no|number)"
        r"|"
        r"cust\s*(?:id|no)"
        r"|"
        r"crn"
        r")"
        r"\s*[:\-]?\s*"
        r"([A-Z0-9Xx*\-]{3,30})",
        re.IGNORECASE,
    )

    # ========================================================
    # Customer name
    # ========================================================

    NAME_LABEL_PATTERN = re.compile(
        r"(?:"
        r"customer\s*name"
        r"|"
        r"account\s*holder(?:\s*name)?"
        r"|"
        r"name"
        r")"
        r"\s*[:\-]?\s*"
        r"([A-Za-z][A-Za-z .'\-]{1,80})",
        re.IGNORECASE,
    )

    # ========================================================
    # Public API
    # ========================================================

    def extract(
        self,
        text: str,
    ) -> StatementMetadataResult:

        if text is None:
            raise ValueError(
                "Text cannot be None."
            )

        if not isinstance(
            text,
            str,
        ):
            raise TypeError(
                "Text must be a string."
            )

        lines = [
            line.strip()
            for line in text.splitlines()
            if line.strip()
        ]

        if not lines:
            return self._empty_result()

        # Metadata should normally live near the beginning of
        # the document.
        #
        # Keeping extraction bounded also reduces the chance
        # that transaction text is mistaken for metadata.
        header_lines = lines[:120]

        header_text = "\n".join(
            header_lines
        )

        statement_period = (
            self._extract_statement_period(
                header_text
            )
        )

        account_number = (
            self._extract_account_number(
                header_lines
            )
        )

        account_type = (
            self._extract_account_type(
                header_lines
            )
        )

        customer_name = (
            self._extract_customer_name(
                header_lines
            )
        )

        ifsc = self._extract_ifsc(
            header_lines
        )

        micr = self._extract_micr(
            header_lines
        )

        branch = self._extract_branch(
            header_lines
        )

        currency = self._extract_currency(
            header_lines
        )

        customer_id = (
            self._extract_customer_id(
                header_lines
            )
        )

        fields = (
            account_number,
            account_type,
            customer_name,
            ifsc,
            micr,
            branch,
            currency,
            customer_id,
        )

        fields_found = sum(
            1
            for field in fields
            if field.value is not None
        )

        confidence_values = [
            field.confidence
            for field in fields
            if field.value is not None
        ]

        if (
            statement_period.start_date
            is not None
            and statement_period.end_date
            is not None
        ):
            confidence_values.append(
                statement_period.confidence
            )

        metadata_confidence = (
            sum(confidence_values)
            / len(confidence_values)
            if confidence_values
            else 0.0
        )

        return StatementMetadataResult(
            statement_period=(
                statement_period
            ),
            account_number=(
                account_number
            ),
            account_type=(
                account_type
            ),
            customer_name=(
                customer_name
            ),
            ifsc=ifsc,
            micr=micr,
            branch=branch,
            currency=currency,
            customer_id=(
                customer_id
            ),
            fields_found=(
                fields_found
            ),
            metadata_confidence=round(
                metadata_confidence,
                4,
            ),
        )

    # ========================================================
    # Statement period
    # ========================================================

    def _extract_statement_period(
        self,
        text: str,
    ) -> StatementPeriod:

        for pattern in self.PERIOD_PATTERNS:

            match = pattern.search(
                text
            )

            if not match:
                continue

            raw_start = (
                match.group(1)
                .strip()
            )

            raw_end = (
                match.group(2)
                .strip()
            )

            start = self._normalize_date(
                raw_start
            )

            end = self._normalize_date(
                raw_end
            )

            if (
                start is None
                or end is None
            ):
                continue

            # Defensive sanity check.
            try:
                start_dt = datetime.strptime(
                    start,
                    "%Y-%m-%d",
                )

                end_dt = datetime.strptime(
                    end,
                    "%Y-%m-%d",
                )

            except ValueError:
                continue

            if start_dt > end_dt:
                continue

            return StatementPeriod(
                start_date=start,
                end_date=end,
                confidence=0.98,
                source=self._clean_source(
                    match.group(0)
                ),
            )

        return StatementPeriod(
            start_date=None,
            end_date=None,
            confidence=0.0,
            source=None,
        )

    # ========================================================
    # Account number
    # ========================================================

    def _extract_account_number(
        self,
        lines: list[str],
    ) -> MetadataField:

        for index, line in enumerate(
            lines
        ):

            for pattern in self.ACCOUNT_PATTERNS:

                match = pattern.search(
                    line
                )

                if not match:
                    continue

                value = (
                    match.group(1)
                    .strip()
                )

                value = (
                    self._clean_identifier(
                        value
                    )
                )

                if self._looks_like_account_number(
                    value
                ):

                    return MetadataField(
                        value=value,
                        confidence=0.98,
                        source=line,
                    )

            # OCR can split:
            #
            # Account No.
            # 1234567890

            if self._is_account_label(
                line
            ):

                next_value = (
                    self._next_identifier_line(
                        lines,
                        index,
                    )
                )

                if (
                    next_value
                    and self._looks_like_account_number(
                        next_value
                    )
                ):

                    return MetadataField(
                        value=next_value,
                        confidence=0.92,
                        source=(
                            line
                            + " "
                            + next_value
                        ),
                    )

        return self._empty_field()

    # ========================================================
    # Account type
    # ========================================================

    def _extract_account_type(
        self,
        lines: list[str],
    ) -> MetadataField:

        for index, line in enumerate(
            lines
        ):

            lower = line.lower()

            for pattern in (
                self.ACCOUNT_TYPE_PATTERNS
            ):

                match = pattern.search(
                    line
                )

                if not match:
                    continue

                candidate = (
                    match.group(1)
                    .strip()
                )

                candidate = (
                    self._trim_label_capture(
                        candidate
                    )
                )

                normalized = (
                    self._normalize_account_type(
                        candidate
                    )
                )

                if normalized:

                    return MetadataField(
                        value=normalized,
                        confidence=0.94,
                        source=line,
                    )

            if (
                "account type"
                in lower
                or "type of account"
                in lower
            ):

                normalized = (
                    self._normalize_account_type(
                        line
                    )
                )

                if normalized:

                    return MetadataField(
                        value=normalized,
                        confidence=0.94,
                        source=line,
                    )

                if index + 1 < len(lines):

                    candidate = (
                        lines[index + 1]
                        .strip()
                    )

                    normalized = (
                        self._normalize_account_type(
                            candidate
                        )
                    )

                    if normalized:

                        return MetadataField(
                            value=normalized,
                            confidence=0.85,
                            source=(
                                line
                                + " "
                                + candidate
                            ),
                        )

        return self._empty_field()

    # ========================================================
    # Customer name
    # ========================================================

    def _extract_customer_name(
        self,
        lines: list[str],
    ) -> MetadataField:
        """
        Name extraction is deliberately conservative.

        Returning None is preferable to assigning an address,
        bank name or arbitrary header line as the customer.
        """

        for index, line in enumerate(
            lines
        ):

            match = (
                self.NAME_LABEL_PATTERN.search(
                    line
                )
            )

            if match:

                candidate = (
                    match.group(1)
                    .strip()
                )

                candidate = (
                    self._trim_name_capture(
                        candidate
                    )
                )

                if self._looks_like_name(
                    candidate
                ):

                    return MetadataField(
                        value=candidate,
                        confidence=0.92,
                        source=line,
                    )

            lower = (
                line.lower()
                .strip(" :.-")
            )

            if lower in {
                "customer name",
                "account holder",
                "account holder name",
                "name",
            }:

                if index + 1 >= len(lines):
                    continue

                candidate = (
                    lines[index + 1]
                    .strip()
                )

                if self._looks_like_name(
                    candidate
                ):

                    return MetadataField(
                        value=candidate,
                        confidence=0.85,
                        source=(
                            line
                            + " "
                            + candidate
                        ),
                    )

        return self._empty_field()

    # ========================================================
    # IFSC
    # ========================================================

    def _extract_ifsc(
        self,
        lines: list[str],
    ) -> MetadataField:

        # Prefer explicit IFSC labels.
        for line in lines:

            match = (
                self.IFSC_LABEL_PATTERN.search(
                    line
                )
            )

            if match:

                return MetadataField(
                    value=(
                        match.group(1)
                        .upper()
                    ),
                    confidence=0.99,
                    source=line,
                )

        # IFSC has a standardized format, so a strict format
        # fallback is reasonably safe.
        for line in lines:

            match = (
                self.IFSC_PATTERN.search(
                    line
                )
            )

            if match:

                return MetadataField(
                    value=(
                        match.group(0)
                        .upper()
                    ),
                    confidence=0.96,
                    source=line,
                )

        return self._empty_field()

    # ========================================================
    # MICR
    # ========================================================

    def _extract_micr(
        self,
        lines: list[str],
    ) -> MetadataField:

        for line in lines:

            match = (
                self.MICR_LABEL_PATTERN.search(
                    line
                )
            )

            if match:

                return MetadataField(
                    value=match.group(1),
                    confidence=0.98,
                    source=line,
                )

        # Do not search arbitrary 9-digit values because phone
        # numbers, account fragments and transaction references
        # can otherwise be mistaken for MICR.
        return self._empty_field()

    # ========================================================
    # Branch
    # ========================================================

    def _extract_branch(
        self,
        lines: list[str],
    ) -> MetadataField:

        for index, line in enumerate(
            lines
        ):

            lower = line.lower()

            # These contain the word "branch" but are not branch
            # names.
            if any(
                blocked in lower
                for blocked in (
                    "branch phone",
                    "branch contact",
                    "branch code",
                    "branch id",
                )
            ):
                continue

            match = (
                self.BRANCH_PATTERN.search(
                    line
                )
            )

            if not match:
                continue

            candidate = (
                match.group(1)
                .strip(" :-")
            )

            candidate = (
                self._trim_branch_capture(
                    candidate
                )
            )

            if self._looks_like_branch(
                candidate
            ):

                return MetadataField(
                    value=candidate,
                    confidence=0.90,
                    source=line,
                )

            # OCR may split:
            #
            # Branch Name
            # SITAMARHI

            if index + 1 < len(lines):

                candidate = (
                    lines[index + 1]
                    .strip()
                )

                if self._looks_like_branch(
                    candidate
                ):

                    return MetadataField(
                        value=candidate,
                        confidence=0.82,
                        source=(
                            line
                            + " "
                            + candidate
                        ),
                    )

        return self._empty_field()

    # ========================================================
    # Currency
    # ========================================================

    def _extract_currency(
        self,
        lines: list[str],
    ) -> MetadataField:

        for index, line in enumerate(
            lines
        ):

            match = (
                self.CURRENCY_PATTERN.search(
                    line
                )
            )

            if match:

                raw_value = (
                    match.group(1)
                    .strip()
                )

                normalized = (
                    self._normalize_currency(
                        raw_value
                    )
                )

                if normalized:

                    return MetadataField(
                        value=normalized,
                        confidence=0.95,
                        source=line,
                    )

            normalized_label = (
                line.lower()
                .strip(" :.-")
            )

            if (
                normalized_label
                == "currency"
                and index + 1 < len(lines)
            ):

                raw_value = (
                    lines[index + 1]
                    .strip()
                )

                normalized = (
                    self._normalize_currency(
                        raw_value
                    )
                )

                if normalized:

                    return MetadataField(
                        value=normalized,
                        confidence=0.85,
                        source=(
                            line
                            + " "
                            + raw_value
                        ),
                    )

        return self._empty_field()

    # ========================================================
    # Customer ID
    # ========================================================

    def _extract_customer_id(
        self,
        lines: list[str],
    ) -> MetadataField:

        for index, line in enumerate(
            lines
        ):

            match = (
                self.CUSTOMER_ID_PATTERN.search(
                    line
                )
            )

            if match:

                value = (
                    match.group(1)
                    .strip()
                )

                if value:

                    return MetadataField(
                        value=value,
                        confidence=0.92,
                        source=line,
                    )

            lower = (
                line.lower()
                .strip(" :.-")
            )

            if lower in {
                "customer id",
                "customer no",
                "customer number",
                "cust id",
                "cust no",
                "crn",
            }:

                next_value = (
                    self._next_identifier_line(
                        lines,
                        index,
                    )
                )

                if next_value:

                    return MetadataField(
                        value=next_value,
                        confidence=0.85,
                        source=(
                            line
                            + " "
                            + next_value
                        ),
                    )

        return self._empty_field()

    # ========================================================
    # Date normalization
    # ========================================================

    @staticmethod
    def _normalize_date(
        value: str,
    ) -> str | None:

        value = (
            value
            .strip()
            .replace(",", "")
        )

        formats = (
            # 23 January 2026
            "%d %B %Y",

            # 23 Jan 2026
            "%d %b %Y",

            # 23 January 26
            "%d %B %y",

            # 23 Jan 26
            "%d %b %y",

            # 23-Jan-2026
            "%d-%b-%Y",

            # 23-January-2026
            "%d-%B-%Y",

            # 23-Jan-26
            "%d-%b-%y",

            # 23-January-26
            "%d-%B-%y",

            # 23/Jan/2026
            "%d/%b/%Y",

            # 23/January/2026
            "%d/%B/%Y",

            # 23/Jan/26
            "%d/%b/%y",

            # 23/January/26
            "%d/%B/%y",

            # Numeric DMY
            "%d/%m/%Y",
            "%d-%m-%Y",
            "%d.%m.%Y",

            "%d/%m/%y",
            "%d-%m-%y",
            "%d.%m.%y",

            # ISO/YMD
            "%Y-%m-%d",
            "%Y/%m/%d",
            "%Y.%m.%d",
        )

        for date_format in formats:

            try:
                parsed = datetime.strptime(
                    value,
                    date_format,
                )

                return parsed.strftime(
                    "%Y-%m-%d"
                )

            except ValueError:
                continue

        return None

    # ========================================================
    # Account type normalization
    # ========================================================

    @classmethod
    def _normalize_account_type(
        cls,
        value: str,
    ) -> str | None:

        if not value:
            return None

        lower = value.lower()

        if "savings" in lower:
            return "Savings"

        if re.search(
            r"\bsaving\b",
            lower,
        ):
            return "Savings"

        if "current" in lower:
            return "Current"

        if "salary" in lower:
            return "Salary"

        if re.search(
            r"\bnre\b",
            lower,
        ):
            return "NRE"

        if re.search(
            r"\bnro\b",
            lower,
        ):
            return "NRO"

        if (
            "overdraft" in lower
            or re.search(
                r"\bod\b",
                lower,
            )
        ):
            return "Overdraft"

        return None

    # ========================================================
    # Currency normalization
    # ========================================================

    @classmethod
    def _normalize_currency(
        cls,
        value: str,
    ) -> str | None:

        if not value:
            return None

        cleaned = re.sub(
            r"\s+",
            " ",
            value,
        ).strip()

        lower = cleaned.lower()

        if lower in cls.CURRENCY_ALIASES:
            return cls.CURRENCY_ALIASES[
                lower
            ]

        # Accept standard-looking 3-letter currency codes.
        if re.fullmatch(
            r"[A-Za-z]{3}",
            cleaned,
        ):
            return cleaned.upper()

        # Do not invent a code for unknown currency text.
        return None

    # ========================================================
    # Identifier helpers
    # ========================================================

    @staticmethod
    def _clean_identifier(
        value: str,
    ) -> str:

        value = value.strip()

        value = re.split(
            r"\s{2,}|"
            r"\b(?:"
            r"account\s*type|"
            r"branch|"
            r"ifsc|"
            r"micr|"
            r"currency|"
            r"customer"
            r")\b",
            value,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]

        return value.strip(
            " :-."
        )

    @staticmethod
    def _looks_like_account_number(
        value: str,
    ) -> bool:

        if not value:
            return False

        compact = re.sub(
            r"[\s\-]",
            "",
            value,
        )

        if not (
            4
            <= len(compact)
            <= 34
        ):
            return False

        # Account identifiers should contain at least one digit
        # or masking character.
        if not re.search(
            r"[\dXx*]",
            compact,
        ):
            return False

        return bool(
            re.fullmatch(
                r"[A-Za-z0-9Xx*]+",
                compact,
            )
        )

    @staticmethod
    def _is_account_label(
        line: str,
    ) -> bool:

        normalized = re.sub(
            r"[^a-z]",
            "",
            line.lower(),
        )

        return normalized in {
            "accountno",
            "accountnumber",
            "acno",
            "acnumber",
        }

    @staticmethod
    def _next_identifier_line(
        lines: list[str],
        index: int,
    ) -> str | None:

        for offset in (
            1,
            2,
        ):

            target = (
                index + offset
            )

            if target >= len(lines):
                break

            candidate = (
                lines[target]
                .strip()
            )

            if not candidate:
                continue

            if len(candidate) > 40:
                continue

            if re.fullmatch(
                r"[A-Za-z0-9Xx*\- ]{3,40}",
                candidate,
            ):
                return candidate

        return None

    # ========================================================
    # Capture cleanup helpers
    # ========================================================

    @staticmethod
    def _trim_label_capture(
        value: str,
    ) -> str:

        value = re.split(
            r"\b(?:"
            r"branch|"
            r"ifsc|"
            r"micr|"
            r"currency|"
            r"account\s*status|"
            r"nominee|"
            r"customer"
            r")\b",
            value,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]

        return value.strip(
            " :-"
        )

    @staticmethod
    def _trim_name_capture(
        value: str,
    ) -> str:

        value = re.split(
            r"\b(?:"
            r"phone|"
            r"mobile|"
            r"address|"
            r"branch|"
            r"customer\s*id|"
            r"account|"
            r"ifsc|"
            r"micr"
            r")\b",
            value,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]

        return value.strip(
            " :-"
        )

    @staticmethod
    def _trim_branch_capture(
        value: str,
    ) -> str:

        value = re.split(
            r"\b(?:"
            r"phone|"
            r"contact|"
            r"ifsc|"
            r"micr|"
            r"address|"
            r"currency"
            r")\b",
            value,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]

        return value.strip(
            " :-"
        )

    # ========================================================
    # Semantic validation helpers
    # ========================================================

    @staticmethod
    def _looks_like_name(
        value: str,
    ) -> bool:

        if not value:
            return False

        value = value.strip()

        if not (
            2
            <= len(value)
            <= 80
        ):
            return False

        if re.search(
            r"\d",
            value,
        ):
            return False

        words = value.split()

        if len(words) > 6:
            return False

        blocked = {
            "statement",
            "account",
            "branch",
            "bank",
            "currency",
            "address",
            "balance",
            "transaction",
            "transactions",
            "particulars",
            "deposit",
            "deposits",
            "withdrawal",
            "withdrawals",
        }

        lower_words = {
            word.lower()
            for word in words
        }

        if (
            lower_words
            & blocked
        ):
            return False

        return bool(
            re.fullmatch(
                r"[A-Za-z .'\-]+",
                value,
            )
        )

    @staticmethod
    def _looks_like_branch(
        value: str,
    ) -> bool:

        if not value:
            return False

        value = value.strip()

        if not (
            2
            <= len(value)
            <= 100
        ):
            return False

        if re.fullmatch(
            r"\d+",
            value,
        ):
            return False

        return True

    # ========================================================
    # General helpers
    # ========================================================

    @staticmethod
    def _clean_source(
        value: str,
    ) -> str:

        return re.sub(
            r"\s+",
            " ",
            value,
        ).strip()

    @staticmethod
    def _empty_field() -> MetadataField:

        return MetadataField(
            value=None,
            confidence=0.0,
            source=None,
        )

    @classmethod
    def _empty_result(
        cls,
    ) -> StatementMetadataResult:

        empty = cls._empty_field()

        return StatementMetadataResult(
            statement_period=StatementPeriod(
                start_date=None,
                end_date=None,
                confidence=0.0,
                source=None,
            ),
            account_number=empty,
            account_type=empty,
            customer_name=empty,
            ifsc=empty,
            micr=empty,
            branch=empty,
            currency=empty,
            customer_id=empty,
            fields_found=0,
            metadata_confidence=0.0,
        )


metadata_extractor = MetadataExtractor()