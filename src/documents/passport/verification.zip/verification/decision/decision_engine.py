from app.verification.decision.confidence_engine import ConfidenceEngine
from app.verification.decision.risk_engine import RiskEngine


class DecisionEngine:
    """
    Combines all verification engines into one final decision.
    """

    def evaluate(
        self,
        mrz_result,
        authenticity_result,
        forgery_result
    ):

        confidence = ConfidenceEngine.calculate(
            mrz_result=mrz_result,
            authenticity_result=authenticity_result,
            forgery_result=forgery_result
        )

        risk = RiskEngine.calculate(
            confidence_result=confidence,
            authenticity_result=authenticity_result,
            forgery_result=forgery_result
        )

        authenticity_score = authenticity_result["authenticity"]["score"]
        forgery_score = forgery_result["summary"]["score"]

        overall_score = round(
            (
                authenticity_score +
                forgery_score +
                confidence["score"]
            ) / 3,
            2
        )

        if risk["level"] == "LOW":
            decision = "GENUINE"

        elif risk["level"] == "MEDIUM":
            decision = "LIKELY_GENUINE"

        elif risk["level"] == "HIGH":
            decision = "SUSPICIOUS"

        else:
            decision = "LIKELY_FAKE"

        warnings = []

        warnings.extend(
            authenticity_result["authenticity"].get(
                "reasons",
                []
            )
        )

        warnings.extend(
            forgery_result["summary"].get(
                "warnings",
                []
            )
        )

        return {

            "passed": decision in [
                "GENUINE",
                "LIKELY_GENUINE"
            ],

            "decision": decision,

            "overall_score": overall_score,

            "confidence": confidence,

            "risk": risk,

            "warnings": warnings

        }