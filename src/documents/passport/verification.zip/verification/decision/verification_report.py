from datetime import datetime


class VerificationReport:
    """
    Generate the final minimal API response.
    """

    @staticmethod
    def generate(
        request_id,
        document_type,
        authenticity_result,
        forgery_result,
        decision_result
    ):
        authenticity = authenticity_result.get("authenticity", {})
        forgery = forgery_result.get("summary", {})
        confidence = decision_result.get("confidence", {})
        risk = decision_result.get("risk", {})

        return {
            "request_id": request_id,

            "timestamp": datetime.utcnow().isoformat() + "Z",

            "document_type": document_type,

            "status": (
                "VERIFIED"
                if decision_result.get("passed", False)
                else "FAILED"
            ),

            "decision": decision_result.get(
                "decision",
                "UNKNOWN"
            ),

            "confidence": confidence.get(
                "confidence",
                0.0
            ),

            "risk": risk.get(
                "level",
                "UNKNOWN"
            ),

            "authenticity_score": authenticity.get(
                "score",
                0
            ),

            "forgery_score": forgery.get(
                "score",
                0
            ),

            "warnings": decision_result.get(
                "warnings",
                []
            )
        }