import cv2
import numpy as np


class BlurAnalysis:
    """
    Detect localized blur inconsistencies that may indicate image tampering.

    Uses the Variance of Laplacian computed over image blocks.
    """

    def __init__(self, block_size=128):
        self.block_size = block_size

    @staticmethod
    def laplacian_variance(gray_image):
        """Compute the variance of the Laplacian."""
        return cv2.Laplacian(
            gray_image,
            cv2.CV_64F
        ).var()

    def analyze(self, image_path):

        image = cv2.imread(image_path)

        if image is None:
            return {
                "passed": False,
                "reason": "Unable to load image."
            }

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        height, width = gray.shape

        block_scores = []

        for y in range(0, height, self.block_size):
            for x in range(0, width, self.block_size):

                block = gray[
                    y:min(y + self.block_size, height),
                    x:min(x + self.block_size, width)
                ]

                if block.size == 0:
                    continue

                score = self.laplacian_variance(block)

                block_scores.append({
                    "x": x,
                    "y": y,
                    "width": block.shape[1],
                    "height": block.shape[0],
                    "blur_score": round(score, 2)
                })

        if not block_scores:
            return {
                "passed": False,
                "reason": "No valid image blocks."
            }

        scores = np.array(
            [b["blur_score"] for b in block_scores],
            dtype=np.float32
        )

        mean_score = float(np.mean(scores))
        std_score = float(np.std(scores))

        suspicious_blocks = []

        # Blocks whose blur differs significantly from the image average
        lower_limit = mean_score - (2 * std_score)
        upper_limit = mean_score + (2 * std_score)

        for block in block_scores:

            if (
                block["blur_score"] < lower_limit
                or
                block["blur_score"] > upper_limit
            ):
                suspicious_blocks.append(block)

        suspicious_ratio = (
            len(suspicious_blocks) / len(block_scores)
        )

        passed = suspicious_ratio < 0.20

        return {

            "passed": passed,

            "mean_blur": round(mean_score, 2),

            "std_blur": round(std_score, 2),

            "total_blocks": len(block_scores),

            "suspicious_blocks": len(suspicious_blocks),

            "suspicious_ratio": round(
                suspicious_ratio,
                3
            ),

            "regions": suspicious_blocks,

            "reason": (
                "No significant localized blur inconsistencies."
                if passed
                else
                "Localized blur inconsistencies detected."
            )

        }