import cv2
import numpy as np


class EdgeConsistency:
    """
    Analyze edge consistency across the document.

    Edited regions often introduce abnormal edge density or
    unnatural edge transitions.
    """

    def __init__(self, block_size=128):
        self.block_size = block_size

    def analyze(self, image_path):

        image = cv2.imread(image_path)

        if image is None:
            return {
                "passed": False,
                "reason": "Unable to load image."
            }

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        edges = cv2.Canny(
            gray,
            100,
            200
        )

        h, w = edges.shape

        blocks = []

        for y in range(0, h, self.block_size):
            for x in range(0, w, self.block_size):

                block = edges[
                    y:min(y + self.block_size, h),
                    x:min(x + self.block_size, w)
                ]

                density = np.count_nonzero(block) / block.size

                blocks.append({

                    "x": x,
                    "y": y,
                    "width": block.shape[1],
                    "height": block.shape[0],
                    "edge_density": round(float(density), 4)

                })

        values = np.array(
            [b["edge_density"] for b in blocks],
            dtype=np.float32
        )

        mean = float(np.mean(values))
        std = float(np.std(values))

        lower = mean - (2 * std)
        upper = mean + (2 * std)

        suspicious = []

        for block in blocks:

            if (
                block["edge_density"] < lower
                or
                block["edge_density"] > upper
            ):
                suspicious.append(block)

        ratio = len(suspicious) / max(len(blocks), 1)

        return {

            "passed": ratio < 0.20,

            "mean_edge_density": round(mean, 4),

            "std_edge_density": round(std, 4),

            "total_blocks": len(blocks),

            "suspicious_blocks": len(suspicious),

            "suspicious_ratio": round(ratio, 3),

            "regions": suspicious,

            "reason": (
                "Edge distribution appears consistent."
                if ratio < 0.20
                else
                "Edge inconsistencies detected."
            )

        }