import cv2
import numpy as np


class IlluminationAnalysis:
    """
    Analyze illumination consistency across the document.

    Local lighting differences may indicate edited or pasted regions.
    """

    def __init__(self, block_size=128):
        self.block_size = block_size

    def analyze(self, image_path):

        image = cv2.imread(image_path)

        if image is None:
            return {
                "passed": False,
                "reason": "Unable to load image."
            }

        lab = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2LAB
        )

        lightness = lab[:, :, 0]

        h, w = lightness.shape

        blocks = []

        for y in range(0, h, self.block_size):
            for x in range(0, w, self.block_size):

                block = lightness[
                    y:min(y + self.block_size, h),
                    x:min(x + self.block_size, w)
                ]

                mean_light = float(np.mean(block))

                blocks.append({

                    "x": x,
                    "y": y,
                    "width": block.shape[1],
                    "height": block.shape[0],
                    "lightness": round(mean_light, 2)

                })

        values = np.array(
            [b["lightness"] for b in blocks],
            dtype=np.float32
        )

        mean = float(np.mean(values))
        std = float(np.std(values))

        lower = mean - (2 * std)
        upper = mean + (2 * std)

        suspicious = []

        for block in blocks:

            if (
                block["lightness"] < lower
                or
                block["lightness"] > upper
            ):
                suspicious.append(block)

        ratio = len(suspicious) / max(len(blocks), 1)

        return {

            "passed": ratio < 0.20,

            "mean_lightness": round(mean, 2),

            "std_lightness": round(std, 2),

            "total_blocks": len(blocks),

            "suspicious_blocks": len(suspicious),

            "suspicious_ratio": round(ratio, 3),

            "regions": suspicious,

            "reason": (
                "Lighting appears consistent."
                if ratio < 0.20
                else
                "Lighting inconsistencies detected."
            )

        }