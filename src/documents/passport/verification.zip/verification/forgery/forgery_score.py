class ForgeryScore:
    """
    Calculate the overall forgery score.
    """

    WEIGHTS = {

        "blur": 15,

        "noise": 20,

        "jpeg": 20,

        "edge": 15,

        "illumination": 10,

        "copy_move": 20

    }

    @classmethod
    def calculate(
        cls,
        blur,
        noise,
        jpeg,
        edge,
        illumination,
        copy_move
    ):

        detectors = {

            "blur": blur,

            "noise": noise,

            "jpeg": jpeg,

            "edge": edge,

            "illumination": illumination,

            "copy_move": copy_move

        }

        score = 0

        details = {}

        warnings = []

        for name, result in detectors.items():

            weight = cls.WEIGHTS[name]

            if result.get("passed", False):

                score += weight

                details[name] = weight

            else:

                details[name] = 0

                warnings.append(
                    result.get(
                        "reason",
                        f"{name} failed."
                    )
                )

        if score >= 90:

            decision = "NO_FORGERY_DETECTED"

        elif score >= 70:

            decision = "LOW_RISK"

        elif score >= 50:

            decision = "MEDIUM_RISK"

        else:

            decision = "HIGH_RISK"

        confidence = round(
            score / 100,
            2
        )

        return {

            "score": score,

            "confidence": confidence,

            "decision": decision,

            "details": details,

            "warnings": warnings

        }