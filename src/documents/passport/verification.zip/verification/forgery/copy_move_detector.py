import cv2
import numpy as np


class CopyMoveDetector:
    """
    Detect possible copy-move forgery using ORB feature matching.
    """

    def __init__(self):

        self.orb = cv2.ORB_create(
            nfeatures=2000
        )

        self.matcher = cv2.BFMatcher(
            cv2.NORM_HAMMING,
            crossCheck=False
        )

    def analyze(self, image_path):

        image = cv2.imread(image_path)

        if image is None:

            return {
                "passed": False,
                "reason": "Unable to load image."
            }

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        keypoints, descriptors = self.orb.detectAndCompute(
            gray,
            None
        )

        if descriptors is None or len(descriptors) < 20:

            return {

                "passed": True,

                "keypoints": len(keypoints),

                "good_matches": 0,

                "clusters": 0,

                "reason": "Insufficient features for analysis."

            }

        matches = self.matcher.knnMatch(
            descriptors,
            descriptors,
            k=2
        )

        good_matches = []

        distances = []

        for pair in matches:

            if len(pair) != 2:
                continue

            m, n = pair

            # Ignore self-match
            if m.queryIdx == m.trainIdx:
                continue

            if m.distance < 0.75 * n.distance:

                pt1 = keypoints[m.queryIdx].pt
                pt2 = keypoints[m.trainIdx].pt

                distance = np.linalg.norm(
                    np.array(pt1) - np.array(pt2)
                )

                # Ignore very close matches
                if distance > 25:

                    good_matches.append(m)

                    distances.append(distance)

        suspicious = len(good_matches) > 80

        return {

            "passed": not suspicious,

            "keypoints": len(keypoints),

            "good_matches": len(good_matches),

            "average_distance": round(
                float(np.mean(distances))
                if distances else 0,
                2
            ),

            "clusters": len(good_matches),

            "reason": (
                "No significant duplicated regions detected."
                if not suspicious
                else
                "Possible copy-move forgery detected."
            )

        }