from app.verification.forgery.blur_analysis import BlurAnalysis
from app.verification.forgery.noise_analysis import NoiseAnalysis
from app.verification.forgery.jpeg_artifact_detector import JPEGArtifactDetector
from app.verification.forgery.edge_consistency import EdgeConsistency
from app.verification.forgery.illumination_analysis import IlluminationAnalysis
from app.verification.forgery.copy_move_detector import CopyMoveDetector
from app.verification.forgery.forgery_score import ForgeryScore


class ForgeryEngine:
    """
    Runs all forgery detectors and produces a unified result.
    """

    def __init__(self):

        self.blur = BlurAnalysis()
        self.noise = NoiseAnalysis()
        self.jpeg = JPEGArtifactDetector()
        self.edge = EdgeConsistency()
        self.illumination = IlluminationAnalysis()
        self.copy_move = CopyMoveDetector()

    def analyze(self, image_path):

        results = {

            "blur": self.blur.analyze(image_path),

            "noise": self.noise.analyze(image_path),

            "jpeg": self.jpeg.analyze(image_path),

            "edge": self.edge.analyze(image_path),

            "illumination": self.illumination.analyze(image_path),

            "copy_move": self.copy_move.analyze(image_path)

        }

        score = ForgeryScore.calculate(

            blur=results["blur"],

            noise=results["noise"],

            jpeg=results["jpeg"],

            edge=results["edge"],

            illumination=results["illumination"],

            copy_move=results["copy_move"]

        )

        return {

            "passed": score["decision"] in [

                "NO_FORGERY_DETECTED",

                "LOW_RISK"

            ],

            "analysis": results,

            "summary": score

        }