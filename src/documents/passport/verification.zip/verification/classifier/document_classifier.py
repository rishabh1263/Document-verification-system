class DocumentClassifier:

    PASSPORT_KEYWORDS = [
        "passport",
        "republic of india",
        "nationality",
        "date of issue",
        "date of expiry",
        "place of issue"
    ]

    PAN_KEYWORDS = [
        "income tax department",
        "permanent account number",
        "govt of india"
    ]

    AADHAAR_KEYWORDS = [
        "aadhaar",
        "government of india",
        "uidai"
    ]

    @classmethod
    def classify(cls, ocr_text: str):

        text = ocr_text.lower()

        passport_score = 0
        pan_score = 0
        aadhaar_score = 0

        for keyword in cls.PASSPORT_KEYWORDS:
            if keyword in text:
                passport_score += 1

        for keyword in cls.PAN_KEYWORDS:
            if keyword in text:
                pan_score += 1

        for keyword in cls.AADHAAR_KEYWORDS:
            if keyword in text:
                aadhaar_score += 1

        if passport_score >= max(pan_score, aadhaar_score) and passport_score > 0:
            return {
                "document_type": "PASSPORT",
                "confidence": round(passport_score / len(cls.PASSPORT_KEYWORDS), 2),
                "eligible": True,
                "reason": "Passport keywords detected."
            }

        if pan_score >= max(passport_score, aadhaar_score) and pan_score > 0:
            return {
                "document_type": "PAN_CARD",
                "confidence": round(pan_score / len(cls.PAN_KEYWORDS), 2),
                "eligible": False,
                "reason": "PAN Card keywords detected."
            }

        if aadhaar_score > 0:
            return {
                "document_type": "AADHAAR",
                "confidence": round(aadhaar_score / len(cls.AADHAAR_KEYWORDS), 2),
                "eligible": False,
                "reason": "Aadhaar keywords detected."
            }

        return {
            "document_type": "UNKNOWN",
            "confidence": 0.0,
            "eligible": False,
            "reason": "Unable to classify document."
        }