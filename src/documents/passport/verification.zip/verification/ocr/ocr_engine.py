import easyocr


class OCREngine:

    reader = easyocr.Reader(
        ['en'],
        gpu=False
    )

    @classmethod
    def extract_text(cls, image_path: str):

        result = cls.reader.readtext(image_path)

        lines = []
        confidences = []

        for item in result:
            lines.append(item[1])
            confidences.append(float(item[2]))

        avg_confidence = (
            sum(confidences) / len(confidences)
            if confidences else 0
        )

        return {

            # Internal use
            "text": " ".join(lines),

            "lines": lines,

            # API
            "preview": lines[:5],

            "line_count": len(lines),

            "average_confidence": round(avg_confidence, 3)
        }