import cv2
import numpy as np


class PhotoDetector:
    """
    Detect the passport photo region without using Haar cascades.

    Checks:
    - Expected photo region contains sufficient edges and texture.
    - Region size is reasonable.
    """

    def detect(self, image_path):

        image = cv2.imread(image_path)

        if image is None:
            return {
                "detected": False,
                "passed": False,
                "reason": "Unable to load image."
            }

        height, width = image.shape[:2]

        # Expected passport photo region
        x1 = int(width * 0.45)
        x2 = int(width * 0.95)

        y1 = int(height * 0.10)
        y2 = int(height * 0.75)

        roi = image[y1:y2, x1:x2]

        if roi.size == 0:
            return {
                "detected": False,
                "passed": False,
                "reason": "Invalid photo region."
            }

        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

        # Measure texture
        edges = cv2.Canny(gray, 75, 150)

        edge_density = np.count_nonzero(edges) / edges.size

        detected = edge_density > 0.03

        return {

            "detected": detected,

            "bounding_box": {
                "x": x1,
                "y": y1,
                "width": x2 - x1,
                "height": y2 - y1
            },

            "edge_density": round(edge_density, 4),

            "expected_region": True,

            "passed": detected
        }