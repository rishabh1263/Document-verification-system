import cv2
import numpy as np


class SignatureDetector:
    """
    Detect the passport signature using OpenCV.

    Checks:
    - Signature exists
    - Located in expected region
    - Reasonable contour size
    """

    @staticmethod
    def detect(image_path):

        image = cv2.imread(image_path)

        if image is None:
            return {
                "detected": False,
                "reason": "Unable to load image."
            }

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        height, width = gray.shape

        # --------------------------------------------------
        # Signature is generally in the lower-right section
        # --------------------------------------------------

        roi = gray[
            int(height * 0.55):int(height * 0.90),
            int(width * 0.45):int(width * 0.95)
        ]

        blurred = cv2.GaussianBlur(
            roi,
            (5, 5),
            0
        )

        thresh = cv2.adaptiveThreshold(
            blurred,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV,
            15,
            8
        )

        kernel = np.ones((2, 2), np.uint8)

        thresh = cv2.morphologyEx(
            thresh,
            cv2.MORPH_OPEN,
            kernel
        )

        contours, _ = cv2.findContours(
            thresh,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )

        valid_contours = []

        total_area = 0

        for contour in contours:

            area = cv2.contourArea(contour)

            if area < 40:
                continue

            x, y, w, h = cv2.boundingRect(contour)

            if w < 8 or h < 4:
                continue

            valid_contours.append(contour)

            total_area += area

        detected = len(valid_contours) >= 5

        coverage = total_area / (roi.shape[0] * roi.shape[1])

        passed = (

            detected

            and

            0.001 <= coverage <= 0.10

        )

        return {

            "detected": detected,

            "passed": passed,

            "contours": len(valid_contours),

            "coverage": round(
                coverage,
                4
            ),

            "expected_region": True,

            "reason": (
                "Signature-like pattern detected."
                if detected
                else
                "No signature-like pattern found."
            )

        }