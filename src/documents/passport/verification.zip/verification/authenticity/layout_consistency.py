import cv2


class LayoutConsistency:
    """
    Passport layout consistency validator.

    Supports both:
    - detect()  (new API)
    - validate() (legacy API)
    """

    @staticmethod
    def validate(
        image_width,
        image_height,
        photo_result,
        signature_result,
        emblem_result,
        mrz_result
    ):

        score = 0
        total = 4

        checks = {}

        photo_ok = photo_result.get("passed", False)
        checks["photo"] = photo_ok
        if photo_ok:
            score += 1

        signature_ok = signature_result.get("passed", False)
        checks["signature"] = signature_ok
        if signature_ok:
            score += 1

        emblem_ok = emblem_result.get("passed", False)
        checks["emblem"] = emblem_ok
        if emblem_ok:
            score += 1

        mrz_ok = (
            mrz_result.get("passed", False)
            or
            mrz_result.get("valid", False)
        )

        checks["mrz"] = mrz_ok
        if mrz_ok:
            score += 1

        confidence = round(score / total, 2)

        return {

            "passed": confidence >= 0.75,

            "confidence": confidence,

            "score": confidence * 100,

            "checks": checks,

            "summary": f"{score}/{total} layout checks passed."

        }

    def detect(
        self,
        image_path,
        photo_result=None,
        signature_result=None,
        emblem_result=None,
        mrz_result=None
    ):

        image = cv2.imread(image_path)

        if image is None:

            return {

                "passed": False,

                "confidence": 0.0,

                "reason": "Unable to load image."

            }

        h, w = image.shape[:2]

        return self.validate(
            image_width=w,
            image_height=h,
            photo_result=photo_result or {},
            signature_result=signature_result or {},
            emblem_result=emblem_result or {},
            mrz_result=mrz_result or {}
        )