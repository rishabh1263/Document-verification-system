from app.verification.mrz.mrz_utils import (
    validate_check_digit,
    validate_date,
)


class MRZValidator:
    """
    ICAO 9303 TD3 Passport MRZ Validator.

    Performs validation of:
    - Document type
    - Passport number
    - Birth date
    - Expiry date
    - Personal number
    - Final composite check digit

    Returns both 'passed' and 'valid' for backward compatibility.
    """

    @classmethod
    def validate(cls, mrz):

        if not mrz.get("parsed", False):

            return {

                "passed": False,

                "valid": False,

                "confidence": 0.0,

                "score": 0,

                "checks": {},

                "errors": [
                    "MRZ could not be parsed."
                ]

            }

        score = 0

        checks = {}

        errors = []

        # -----------------------------------
        # Document Type
        # -----------------------------------

        checks["document_type"] = (
            mrz.get("document_type") == "P"
        )

        if checks["document_type"]:
            score += 10
        else:
            errors.append("Invalid document type.")

        # -----------------------------------
        # Passport Number
        # -----------------------------------

        checks["passport_number"] = validate_check_digit(
            mrz.get("passport_number", ""),
            mrz.get("passport_number_check", "")
        )

        if checks["passport_number"]:
            score += 20
        else:
            errors.append("Passport number checksum failed.")

        # -----------------------------------
        # Birth Date
        # -----------------------------------

        checks["birth_date"] = (

            validate_date(
                mrz.get("birth_date", "")
            )

            and

            validate_check_digit(
                mrz.get("birth_date", ""),
                mrz.get("birth_date_check", "")
            )

        )

        if checks["birth_date"]:
            score += 20
        else:
            errors.append("Birth date validation failed.")

        # -----------------------------------
        # Expiry Date
        # -----------------------------------

        checks["expiry_date"] = (

            validate_date(
                mrz.get("expiry_date", "")
            )

            and

            validate_check_digit(
                mrz.get("expiry_date", ""),
                mrz.get("expiry_date_check", "")
            )

        )

        if checks["expiry_date"]:
            score += 20
        else:
            errors.append("Expiry date validation failed.")

        # -----------------------------------
        # Personal Number
        # -----------------------------------

        checks["personal_number"] = validate_check_digit(
            mrz.get("personal_number", ""),
            mrz.get("personal_number_check", "")
        )

        if checks["personal_number"]:
            score += 10
        else:
            errors.append("Personal number checksum failed.")

        # -----------------------------------
        # Composite Check Digit
        # -----------------------------------

        composite = (

            mrz.get("passport_number", "")
            + mrz.get("passport_number_check", "")

            + mrz.get("birth_date", "")
            + mrz.get("birth_date_check", "")

            + mrz.get("expiry_date", "")
            + mrz.get("expiry_date_check", "")

            + mrz.get("personal_number", "")
            + mrz.get("personal_number_check", "")

        )

        checks["final_check"] = validate_check_digit(
            composite,
            mrz.get("final_check", "")
        )

        if checks["final_check"]:
            score += 20
        else:
            errors.append("Composite checksum failed.")

        # -----------------------------------
        # Confidence
        # -----------------------------------

        confidence = round(score / 100, 2)

        # -----------------------------------
        # Critical Validation
        # -----------------------------------

        critical = (

            checks["document_type"]

            and

            checks["passport_number"]

            and

            checks["birth_date"]

            and

            checks["expiry_date"]

        )

        return {

            "passed": critical,

            "valid": critical,

            "score": score,

            "confidence": confidence,

            "checks": checks,

            "errors": errors

        }