import re


class MRZCorrector:
    """
    Position-aware OCR correction for ICAO TD3 passport MRZ.

    The parser extracts raw MRZ lines from OCR.
    This class corrects common OCR mistakes before validation.
    """

    LETTER_MAP = {
        "0": "O",
        "1": "I",
        "2": "Z",
        "5": "S",
        "6": "G",
        "8": "B"
    }

    DIGIT_MAP = {
        "O": "0",
        "Q": "0",
        "D": "0",

        "I": "1",
        "L": "1",

        "S": "5",
        "B": "8",

        "Z": "2",

        "G": "6"
    }

    @classmethod
    def correct(cls, line1: str, line2: str):

        line1 = line1.upper()
        line2 = line2.upper()

        line1 = cls.correct_line1(line1)
        line2 = cls.correct_line2(line2)

        return line1, line2

    # -------------------------------------------------------
    # Line 1
    # -------------------------------------------------------

    @classmethod
    def correct_line1(cls, line):

        line = list(line)

        # Document Type
        line[0] = "P"

        # Issuing Country (2-4)
        for i in range(2, 5):
            line[i] = cls.to_letter(line[i])

        return "".join(line)

    # -------------------------------------------------------
    # Line 2
    # -------------------------------------------------------

    @classmethod
    def correct_line2(cls, line):

        line = list(line)

        # Passport Number
        line[0] = cls.to_letter(line[0])

        for i in range(1, 9):
            line[i] = cls.to_digit(line[i])

        line[9] = cls.to_digit(line[9])

        # Nationality
        for i in range(10, 13):
            line[i] = cls.to_letter(line[i])

        # Birth Date
        for i in range(13, 19):
            line[i] = cls.to_digit(line[i])

        line[19] = cls.to_digit(line[19])

        # Gender
        if line[20] not in ["M", "F", "<"]:
            line[20] = "<"

        # Expiry Date
        for i in range(21, 27):
            line[i] = cls.to_digit(line[i])

        line[27] = cls.to_digit(line[27])

        # Personal Number
        for i in range(28, 42):

            if line[i].isdigit():
                continue

            if line[i] == "<":
                continue

            if re.match(r"[A-Z]", line[i]):
                continue

            line[i] = "<"

        line[42] = cls.to_digit(line[42])

        line[43] = cls.to_digit(line[43])

        return "".join(line)

    # -------------------------------------------------------
    # Helpers
    # -------------------------------------------------------

    @classmethod
    def to_letter(cls, ch):

        return cls.LETTER_MAP.get(ch, ch)

    @classmethod
    def to_digit(cls, ch):

        return cls.DIGIT_MAP.get(ch, ch)