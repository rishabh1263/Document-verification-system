import re


class MRZCandidate:

    @staticmethod
    def clean_line(line: str) -> str:
        """
        Keep only valid MRZ characters.
        """

        line = line.upper()

        line = line.replace(" ", "")

        line = re.sub(
            r"[^A-Z0-9<]",
            "",
            line
        )

        return line

    @classmethod
    def find(cls, ocr_lines):

        candidates = []

        for line in ocr_lines:

            cleaned = cls.clean_line(line)

            # MRZ always contains '<'
            if "<" not in cleaned:
                continue

            # Ignore tiny fragments
            if len(cleaned) < 15:
                continue

            candidates.append(cleaned)

        # Merge broken MRZ lines
        merged = []

        current = ""

        for line in candidates:

            if not current:

                current = line

                continue

            if len(current) < 44:

                current += line

            else:

                merged.append(current)

                current = line

        if current:

            merged.append(current)

        # Keep only reasonable candidates
        merged = [

            line

            for line in merged

            if len(line) >= 30

        ]

        if len(merged) >= 2:

            return merged[-2:]

        return merged