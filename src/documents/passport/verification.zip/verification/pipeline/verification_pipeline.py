from app.verification.layout.layout_verifier import LayoutVerifier
from app.verification.mrz.mrz_detector import MRZDetector
from app.verification.mrz.mrz_parser import MRZParser
from app.verification.mrz.mrz_validator import MRZValidator
from app.verification.ocr.ocr_engine import OCREngine
from app.verification.classifier.document_classifier import DocumentClassifier
from app.verification.analysis.page_analyzer import PageAnalyzer
from app.verification.fields.field_extractor import FieldExtractor
from app.verification.fields.field_validator import FieldValidator
from app.verification.authenticity.authenticity_engine import AuthenticityEngine
from app.verification.forgery.forgery_engine import ForgeryEngine
from app.verification.decision.decision_engine import DecisionEngine
from app.verification.decision.verification_report import VerificationReport


class VerificationPipeline:

    @classmethod
    def verify(cls, processed_images):
        pages = []

        best_page = None
        highest_score = -1

        passport_pages = 0
        non_passport_pages = 0

        for index, image in enumerate(processed_images, start=1):
            layout = LayoutVerifier.verify(image)
            mrz = MRZDetector.detect(image)

            ocr = OCREngine.extract_text(image)

            mrz_parsed = MRZParser.parse(ocr["text"])
            mrz_validation = MRZValidator.validate(mrz_parsed)

            visible_fields = FieldExtractor.extract(ocr)
            field_validation = FieldValidator.validate(
                visible_fields,
                mrz_parsed
            )

            document = DocumentClassifier.classify(ocr["text"])

            analysis = PageAnalyzer.analyze(
                page_number=index,
                layout=layout,
                mrz=mrz,
                document=document
            )

            if document["document_type"] == "PASSPORT":
                passport_pages += 1
            else:
                non_passport_pages += 1

            page = {
                "image": image,
                "ocr": {
                    "line_count": ocr["line_count"],
                    "average_confidence": ocr["average_confidence"],
                    "preview": ocr["preview"]
                },
                "layout": layout,
                "mrz": {
                    "detector": mrz,
                    "parsed": mrz_parsed,
                    "validation": mrz_validation
                },
                "fields": {
                    "visible": visible_fields,
                    "consistency": field_validation
                },
                "document": document,
                "analysis": analysis
            }

            pages.append(page)

            if analysis["score"] > highest_score:
                highest_score = analysis["score"]
                best_page = index

        for page in pages:
            page["analysis"]["candidate"] = (
                page["analysis"]["page"] == best_page
            )

        # -------------------------
        # Summary
        # -------------------------

        summary = {
            "passport_pages": passport_pages,
            "non_passport_pages": non_passport_pages,
            "selected_page": best_page,
            "overall_status":
                "PASSPORT_DETECTED"
                if passport_pages
                else "NO_PASSPORT_FOUND",
            "ready_for_authenticity_checks":
                passport_pages > 0
        }

        # ------------------------------------
        # No passport found
        # ------------------------------------

        if best_page is None:
            return {
                "summary": summary,
                "pages": pages
            }

        # ------------------------------------
        # Selected passport page
        # ------------------------------------

        selected = pages[best_page - 1]

        # ------------------------------------
        # Authenticity Engine
        # ------------------------------------

        authenticity = AuthenticityEngine().verify(
            image_path=selected["image"],
            mrz_validation=selected["mrz"]["validation"],
            field_consistency=selected["fields"]["consistency"],
            quality_result=selected["layout"]
        )

        # ------------------------------------
        # Forgery Engine
        # ------------------------------------

        forgery = ForgeryEngine().analyze(
            selected["image"]
        )

        # ------------------------------------
        # Decision Engine
        # ------------------------------------

        decision = DecisionEngine().evaluate(
            mrz_result=selected["mrz"]["validation"],
            authenticity_result=authenticity,
            forgery_result=forgery
        )

        # ------------------------------------
        # Final Minimal Response
        # ------------------------------------

        return VerificationReport.generate(
            request_id="",
            document_type=selected["document"]["document_type"],
            authenticity_result=authenticity,
            forgery_result=forgery,
            decision_result=decision
        )