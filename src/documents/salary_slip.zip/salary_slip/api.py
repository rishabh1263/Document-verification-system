﻿"""
Salary Slip Verification API Router.

Unified-project FastAPI router for Salary Slip extraction
and document verification.

Supports:
- PDF
- JPG / JPEG
- PNG
- BMP
- TIFF

Response:
- Single salary slip -> extracted_fields
- Multi-page salary slips -> salary_slips
- Verification result
"""

import os
import shutil
import tempfile

from fastapi import (
    APIRouter,
    File,
    HTTPException,
    UploadFile,
)

from src.documents.salary_slip.pipeline import process_document


# ============================================================
# ROUTER
# ============================================================

router = APIRouter(
    tags=["Salary Slip"],
)


# ============================================================
# SUPPORTED FILE TYPES
# ============================================================

SUPPORTED_EXTENSIONS = {
    ".pdf",
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".tif",
    ".tiff",
}


# ============================================================
# ROOT
# ============================================================

@router.get("/")
def root():
    return {
        "status": "ok",
        "service": "Salary Slip Verification API",
    }


# ============================================================
# HEALTH
# ============================================================

@router.get("/health")
def health():
    return {
        "status": "healthy",
        "document": "salary_slip",
    }


# ============================================================
# VERIFY
# ============================================================

@router.post(
    "/verify",
    summary="Verify Salary Slip",
    description=(
        "Upload a salary slip PDF or image. "
        "The API extracts salary-slip fields and performs "
        "document verification and risk analysis."
    ),
)
async def verify_salary_slip(
    file: UploadFile = File(...),
):
    """
    Upload and verify one salary-slip document.
    """

    # ========================================================
    # FILE NAME VALIDATION
    # ========================================================

    if not file.filename:
        raise HTTPException(
            status_code=400,
            detail="File name is missing.",
        )

    extension = os.path.splitext(
        file.filename
    )[1].lower()

    # ========================================================
    # FILE TYPE VALIDATION
    # ========================================================

    if extension not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unsupported file type: {extension}. "
                "Supported formats: PDF, JPG, JPEG, "
                "PNG, BMP, TIF, TIFF."
            ),
        )

    temp_path = None

    try:

        # ====================================================
        # SAVE UPLOAD TEMPORARILY
        # ====================================================

        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=extension,
        ) as temp_file:

            shutil.copyfileobj(
                file.file,
                temp_file,
            )

            temp_path = temp_file.name

        # ====================================================
        # RUN SALARY SLIP PIPELINE
        # ====================================================

        result = process_document(
            temp_path
        )

        if not isinstance(result, dict):
            raise RuntimeError(
                "Salary Slip pipeline returned an invalid result."
            )

        # ====================================================
        # BASIC RESPONSE
        # ====================================================

        response = {
            "status": "success",
            "file_name": file.filename,
            "document_type": result.get(
                "doc_type"
            ),
        }

        # ====================================================
        # MULTI-PAGE SALARY SLIPS
        # ====================================================

        salary_slips = result.get(
            "salary_slips"
        )

        if salary_slips:

            clean_slips = []

            for slip in salary_slips:

                fields = dict(
                    slip.get(
                        "extracted_fields",
                        {},
                    )
                    or {}
                )

                # Internal numeric helper values are required
                # for consistency verification but should not
                # be returned through the public API.
                fields.pop(
                    "_numeric",
                    None,
                )

                clean_slips.append(
                    {
                        "page": slip.get(
                            "page"
                        ),

                        "document_type": slip.get(
                            "document_type",
                            "salary_slip",
                        ),

                        "classification_confidence": slip.get(
                            "classification_confidence"
                        ),

                        "extracted_fields": fields,
                    }
                )

            response["page_count"] = result.get(
                "page_count",
                len(clean_slips),
            )

            response["salary_slips"] = clean_slips

        # ====================================================
        # SINGLE SALARY SLIP
        # ====================================================

        else:

            fields = dict(
                result.get(
                    "extracted_fields",
                    {},
                )
                or {}
            )

            fields.pop(
                "_numeric",
                None,
            )

            response["extracted_fields"] = fields

            if result.get(
                "page_count"
            ) is not None:

                response["page_count"] = result.get(
                    "page_count"
                )

        # ====================================================
        # VERIFICATION
        # ====================================================

        risk = result.get(
            "risk_assessment",
            {},
        ) or {}

        response["verification"] = {

            "risk_score": risk.get(
                "risk_score",
                0,
            ),

            "verification_confidence": risk.get(
                "verification_confidence",
                0,
            ),

            "verdict": risk.get(
                "verdict",
                "INSUFFICIENT EVIDENCE",
            ),
        }

        # ====================================================
        # FINAL RESPONSE
        # ====================================================

        return response

    # ========================================================
    # KNOWN HTTP ERROR
    # ========================================================

    except HTTPException:
        raise

    # ========================================================
    # PROCESSING ERROR
    # ========================================================

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Salary Slip processing failed: "
                f"{str(exc)}"
            ),
        ) from exc

    # ========================================================
    # CLEANUP
    # ========================================================

    finally:

        if (
            temp_path
            and os.path.exists(
                temp_path
            )
        ):

            try:
                os.remove(
                    temp_path
                )
            except OSError:
                pass

        try:
            await file.close()
        except Exception:
            pass