"""
CIBIL Verification API.

Single endpoint:
    POST /cibil/verify
"""

from typing import Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel

from .cibil_verification import verify_cibil_document


# ============================================================
# ROUTER
# ============================================================

router = APIRouter(
    prefix="/cibil",
    tags=["CIBIL Verification"],
)


# ============================================================
# CONFIGURATION
# ============================================================

ALLOWED_CONTENT_TYPES = {
    "application/pdf",
}


# ============================================================
# RESPONSE MODEL
# ============================================================

class CibilVerificationResponse(BaseModel):
    verified: bool
    decision: str

    overall_status: Optional[str] = None
    applicant: Optional[dict] = None

    score_analysis: Optional[dict] = None
    account_summary: Optional[dict] = None
    risk_summary: Optional[dict] = None

    decision_reason: Optional[str] = None

    report_freshness: Optional[dict] = None
    credit_vintage: Optional[dict] = None
    utilisation: Optional[dict] = None
    debt_analysis: Optional[dict] = None
    enquiries: Optional[dict] = None

    raw_result: Optional[dict] = None


class ErrorResponse(BaseModel):
    detail: str


# ============================================================
# VERIFY CIBIL
# ============================================================

@router.post(
    "/verify",
    response_model=CibilVerificationResponse,
    responses={
        400: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
    summary="Verify a CIBIL report PDF",
)
async def verify_cibil(
    file: UploadFile = File(
        ...,
        description="CIBIL/credit report PDF",
    ),
    applicant_pan: Optional[str] = Form(
        default=None,
        description="Optional applicant PAN for validation",
    ),
) -> CibilVerificationResponse:

    # --------------------------------------------------------
    # FILE TYPE
    # --------------------------------------------------------

    content_type = (
        file.content_type or ""
    ).lower().strip()

    if content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unsupported file type: "
                f"{file.content_type}. "
                "Only PDF CIBIL reports are supported."
            ),
        )

    # --------------------------------------------------------
    # READ FILE
    # --------------------------------------------------------

    file_bytes = await file.read()

    if not file_bytes:
        raise HTTPException(
            status_code=400,
            detail="Uploaded file is empty.",
        )

    # --------------------------------------------------------
    # VERIFY
    # --------------------------------------------------------

    try:
        result = await run_in_threadpool(
            verify_cibil_document,
            file_bytes,
            applicant_pan=applicant_pan,
        )

    except ValueError as exc:
        raise HTTPException(
            status_code=422,
            detail=str(exc),
        ) from exc

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"CIBIL verification failed: {exc}",
        ) from exc

    # --------------------------------------------------------
    # DECISION
    # --------------------------------------------------------

    decision = str(
        result.get("decision")
        or result.get("overall_status")
        or "REJECTED"
    ).upper()

    verified = decision == "APPROVED"

    # --------------------------------------------------------
    # RESPONSE
    # --------------------------------------------------------

    return CibilVerificationResponse(
        verified=verified,
        decision=decision,

        overall_status=result.get(
            "overall_status"
        ),

        applicant=result.get(
            "applicant"
        ),

        score_analysis=result.get(
            "score_analysis"
        ),

        account_summary=result.get(
            "account_summary"
        ),

        risk_summary=result.get(
            "risk_summary"
        ),

        decision_reason=result.get(
            "decision_reason"
        ),

        report_freshness=result.get(
            "report_freshness"
        ),

        credit_vintage=result.get(
            "credit_vintage"
        ),

        utilisation=result.get(
            "utilisation"
        ),

        debt_analysis=result.get(
            "debt_analysis"
        ),

        enquiries=result.get(
            "enquiries"
        ),

        raw_result=result,
    )